import { expect, test } from "@playwright/test";
import { trpcMutation, trpcQuery } from "../../helpers/api";
import { getAdminCookie } from "../../helpers/auth";
import { TEST_BANK_ID, createTestResource } from "../../helpers/factories";

let adminCookie: string;

test.beforeAll(async ({ request }) => {
  adminCookie = await getAdminCookie(request);
});

// PROOF-B-013-BL — Business Logic: POST /api/accounts requires advisor or admin authorization
// Risk: critical | Endpoint: accounts.create
// Spec: Endpoints
// Behavior: POST /api/accounts requires advisor or admin authorization

test("PROOF-B-013-BLa — POST /api/accounts requires advisor or admin authorization", async ({ request }) => {
  // Precondition: User attempts to create an account
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined();

  // Act
  const { data, status } = await trpcMutation(request, "accounts.create", {
    accountId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in accounts.create
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  // Kills: Remove success path in accounts.create
});
test("PROOF-B-013-BLb — POST /api/accounts requires advisor or admin authorization requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  const { status } = await trpcMutation(request, "accounts.create", {
    accountId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from accounts.create
});
test("PROOF-B-013-BLc — POST /api/accounts requires advisor or admin authorization persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined(); // Kills: Don't return id from accounts.create
  const { data: fetched, status } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove accounts.list endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === accountId)).toBe(true); // Kills: Don't persist to DB
});

// PROOF-B-015-BL — Business Logic: Initial deposit is added to balance atomically
// Risk: high | Endpoint: accounts.create
// Spec: Endpoints
// Behavior: Initial deposit is added to balance atomically

test("PROOF-B-015-BLa — balance deducted after Initial deposit is added to balance atomically", async ({ request }) => {
  // Arrange: Create fromAccount and toAccount with known balances
  const fromAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const toAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(fromAccount?.id).toBeDefined();
  expect(toAccount?.id).toBeDefined();

  // Read balance BEFORE transaction
  const { data: fromBefore } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  const balanceBefore = (Array.isArray(fromBefore) ? fromBefore : [fromBefore])
    .find((a: unknown) => (a as Record<string, unknown>).id === fromAccount.id)
    ?.balance as number ?? 0;
  expect(typeof balanceBefore).toBe("number");
  // Kills: Cannot read balance before transaction

  // Act: Execute the transaction
  const AMOUNT = 1;
  const { status, data } = await trpcMutation(request, "accounts.create", {
    bankId: TEST_BANK_ID,
    customerId: 1,
    accountType: "checking",
    initialDeposit: 1,
  }, adminCookie);
  expect(status).toBe(200);
  // Kills: Remove success path in accounts.create

  // Read balance AFTER transaction
  const { data: fromAfter } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  const balanceAfter = (Array.isArray(fromAfter) ? fromAfter : [fromAfter])
    .find((a: unknown) => (a as Record<string, unknown>).id === fromAccount.id)
    ?.balance as number;

  expect(balanceAfter).toBe(balanceBefore - AMOUNT);
  // Kills: Not deducting amount from fromAccount.balance
  expect(balanceAfter).toBeGreaterThanOrEqual(0);
  // Kills: Allow negative balance (insufficient funds check missing)
  // Kills: Remove success path in accounts.create
  // Kills: Not updating Account balance reflects initialDeposit, operation is atomic after is added in accounts.create
});
test("PROOF-B-015-BLb — Initial deposit is added to balance atomically requires auth", async ({ request }) => {
  const fromAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const toAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const { status } = await trpcMutation(request, "accounts.create", {
    bankId: TEST_BANK_ID,
    fromAccountId: fromAccount.id as number,
    toAccountId: toAccount.id as number,
    amount: 1,
  }, ""); // No cookie
  expect([401, 403]).toContain(status);
  // Kills: Remove auth middleware from accounts.create
});

// PROOF-B-021-BL — Business Logic: GET /api/accounts advisor/admin can filter by customerId
// Risk: critical | Endpoint: accounts.list
// Spec: Endpoints
// Behavior: GET /api/accounts advisor/admin can filter by customerId

test("PROOF-B-021-BLa — GET /api/accounts advisor/admin can filter by customerId", async ({ request }) => {
  // Precondition: User has 'advisor' or 'admin' role
  // Precondition: Requests GET /api/accounts with `customerId` query param
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined();

  // Side-Effect-Check: Read counter BEFORE action
  const { data: before } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  const countBefore = (before as Record<string, unknown>)?.count as number ?? 0;
  // Act
  const { data, status } = await trpcMutation(request, "accounts.list", {
    accountId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in accounts.list
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  const { data: after } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  const countAfter = (after as Record<string, unknown>)?.count as number ?? 0;
  expect(countAfter).toBe(countBefore + 1);
  // Kills: Not incrementing counter in accounts.list
  // Kills: Remove success path in accounts.list
  // Kills: Not updating Response contains accounts filtered by `customerId` within their bankId after can filter in accounts.list
});
test("PROOF-B-021-BLb — GET /api/accounts advisor/admin can filter by customerId requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  const { status } = await trpcMutation(request, "accounts.list", {
    accountId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from accounts.list
});
test("PROOF-B-021-BLc — GET /api/accounts advisor/admin can filter by customerId persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined(); // Kills: Don't return id from accounts.list
  const { data: fetched, status } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove accounts.list endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === accountId)).toBe(true); // Kills: Don't persist to DB
});

// PROOF-B-022-BL — Business Logic: GET /api/accounts advisor/admin can see all accounts within bank
// Risk: critical | Endpoint: accounts.list
// Spec: Endpoints
// Behavior: GET /api/accounts advisor/admin can see all accounts within bank

test("PROOF-B-022-BLa — GET /api/accounts advisor/admin can see all accounts within bank", async ({ request }) => {
  // Precondition: User has 'advisor' or 'admin' role
  // Precondition: Requests GET /api/accounts without `customerId` query param
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined();

  // Side-Effect-Check: Read counter BEFORE action
  const { data: before } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  const countBefore = (before as Record<string, unknown>)?.count as number ?? 0;
  // Act
  const { data, status } = await trpcMutation(request, "accounts.list", {
    accountId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in accounts.list
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  const { data: after } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  const countAfter = (after as Record<string, unknown>)?.count as number ?? 0;
  expect(countAfter).toBe(countBefore + 1);
  // Kills: Not incrementing counter in accounts.list
  // Kills: Remove success path in accounts.list
  // Kills: Not updating Response contains all accounts within their bankId after can see in accounts.list
});
test("PROOF-B-022-BLb — GET /api/accounts advisor/admin can see all accounts within  requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  const { status } = await trpcMutation(request, "accounts.list", {
    accountId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from accounts.list
});
test("PROOF-B-022-BLc — GET /api/accounts advisor/admin can see all accounts within  persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined(); // Kills: Don't return id from accounts.list
  const { data: fetched, status } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove accounts.list endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === accountId)).toBe(true); // Kills: Don't persist to DB
});

// PROOF-B-027-BL — Business Logic: POST /api/transactions requires advisor or admin authorization
// Risk: critical | Endpoint: transactions.create
// Spec: Endpoints
// Behavior: POST /api/transactions requires advisor or admin authorization

test("PROOF-B-027-BLa — POST /api/transactions requires advisor or admin authorization", async ({ request }) => {
  // Precondition: User attempts to create a transaction
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined();

  // Act
  const { data, status } = await trpcMutation(request, "transactions.create", {
    accountId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in transactions.create
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  // Kills: Remove success path in transactions.create
});
test("PROOF-B-027-BLb — POST /api/transactions requires advisor or admin authorizati requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  const { status } = await trpcMutation(request, "transactions.create", {
    accountId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from transactions.create
});
test("PROOF-B-027-BLc — POST /api/transactions requires advisor or admin authorizati persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined(); // Kills: Don't return id from transactions.create
  const { data: fetched, status } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove accounts.list endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === accountId)).toBe(true); // Kills: Don't persist to DB
});

// PROOF-B-031-BL — Business Logic: Amount is deducted from fromAccount and credited to toAccount atomically
// Risk: high | Endpoint: transactions.create
// Spec: Endpoints
// Behavior: Amount is deducted from fromAccount and credited to toAccount atomically

test("PROOF-B-031-BLa — balance deducted after Amount is deducted from fromAccount and credited t", async ({ request }) => {
  // Arrange: Create fromAccount and toAccount with known balances
  const fromAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const toAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(fromAccount?.id).toBeDefined();
  expect(toAccount?.id).toBeDefined();

  // Read balance BEFORE transaction
  const { data: fromBefore } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  const balanceBefore = (Array.isArray(fromBefore) ? fromBefore : [fromBefore])
    .find((a: unknown) => (a as Record<string, unknown>).id === fromAccount.id)
    ?.balance as number ?? 0;
  expect(typeof balanceBefore).toBe("number");
  // Kills: Cannot read balance before transaction

  // Act: Execute the transaction
  const AMOUNT = 1;
  const { status, data } = await trpcMutation(request, "transactions.create", {
    bankId: TEST_BANK_ID,
    fromAccountId: fromAccount.id as number,
    toAccountId: toAccount.id as number,
    amount: AMOUNT,
    description: "Test description",
    idempotencyKey: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200);
  // Kills: Remove success path in transactions.create

  // Read balance AFTER transaction
  const { data: fromAfter } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  const balanceAfter = (Array.isArray(fromAfter) ? fromAfter : [fromAfter])
    .find((a: unknown) => (a as Record<string, unknown>).id === fromAccount.id)
    ?.balance as number;

  expect(balanceAfter).toBe(balanceBefore - AMOUNT);
  // Kills: Not deducting amount from fromAccount.balance
  expect(balanceAfter).toBeGreaterThanOrEqual(0);
  // Kills: Allow negative balance (insufficient funds check missing)
  // Kills: Remove success path in transactions.create
  // Kills: Not updating `fromAccountId` balance decreases, `toAccountId` balance increases, operation is atomic after is deducted and credited atomically in transactions.create
});
test("PROOF-B-031-BLb — Amount is deducted from fromAccount and credited to toAccoun requires auth", async ({ request }) => {
  const fromAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const toAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const { status } = await trpcMutation(request, "transactions.create", {
    bankId: TEST_BANK_ID,
    fromAccountId: fromAccount.id as number,
    toAccountId: toAccount.id as number,
    amount: 1,
  }, ""); // No cookie
  expect([401, 403]).toContain(status);
  // Kills: Remove auth middleware from transactions.create
});

// PROOF-B-036-BL — Business Logic: PATCH /api/transactions/:id/status requires admin authorization
// Risk: critical | Endpoint: transactions.status
// Spec: Endpoints
// Behavior: PATCH /api/transactions/:id/status requires admin authorization

test("PROOF-B-036-BLa — PATCH /api/transactions/:id/status requires admin authorization", async ({ request }) => {
  // Precondition: User attempts to update transaction status
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined();

  // Act
  const { data, status } = await trpcMutation(request, "transactions.status", {
    accountId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in transactions.status
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  // Kills: Remove success path in transactions.status
});
test("PROOF-B-036-BLb — PATCH /api/transactions/:id/status requires admin authorizat requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  const { status } = await trpcMutation(request, "transactions.status", {
    accountId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from transactions.status
});
test("PROOF-B-036-BLc — PATCH /api/transactions/:id/status requires admin authorizat persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined(); // Kills: Don't return id from transactions.status
  const { data: fetched, status } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove accounts.list endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === accountId)).toBe(true); // Kills: Don't persist to DB
});

// PROOF-B-049-BL — Business Logic: DELETE /api/accounts/:id requires admin authorization
// Risk: critical | Endpoint: accounts.delete
// Spec: Endpoints
// Behavior: DELETE /api/accounts/:id requires admin authorization

test("PROOF-B-049-BLa — DELETE /api/accounts/:id requires admin authorization", async ({ request }) => {
  // Arrange: Create a real resource
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined();

  // Act: Delete resource
  const { status, data } = await trpcMutation(request, "accounts.delete", {
    accountId,
    bankId: TEST_BANK_ID,
  }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove success path in accounts.delete

  expect((data as Record<string, unknown>)?.success).toBe(true);
  // Kills: Return success:false on deletion

  // DB-Check: Resource must be gone
  const { status: getStatus } = await trpcQuery(request, "accounts.list",
    { accountId, bankId: TEST_BANK_ID }, adminCookie);
  expect(getStatus).toBe(404);
  // Kills: Soft-delete instead of hard-delete
});

test("PROOF-B-049-BLb — DELETE /api/accounts/:id requires admin authorization requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;

  const { status } = await trpcMutation(request, "accounts.delete", {
    accountId,
    bankId: TEST_BANK_ID,
  }, ""); // No cookie

  expect([401, 403]).toContain(status);
  // Kills: Remove auth middleware from accounts.delete
});

// PROOF-B-054-BL — Business Logic: POST /api/accounts/:id/freeze requires admin authorization
// Risk: critical | Endpoint: accounts.freeze
// Spec: Endpoints
// Behavior: POST /api/accounts/:id/freeze requires admin authorization

test("PROOF-B-054-BLa — POST /api/accounts/:id/freeze requires admin authorization", async ({ request }) => {
  // Precondition: User attempts to freeze an account
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined();

  // Act
  const { data, status } = await trpcMutation(request, "accounts.freeze", {
    accountId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in accounts.freeze
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  // Kills: Remove success path in accounts.freeze
});
test("PROOF-B-054-BLb — POST /api/accounts/:id/freeze requires admin authorization requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  const { status } = await trpcMutation(request, "accounts.freeze", {
    accountId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from accounts.freeze
});
test("PROOF-B-054-BLc — POST /api/accounts/:id/freeze requires admin authorization persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined(); // Kills: Don't return id from accounts.freeze
  const { data: fetched, status } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove accounts.list endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === accountId)).toBe(true); // Kills: Don't persist to DB
});

// PROOF-B-056-BL — Business Logic: Frozen accounts cannot send transactions
// Risk: high | Endpoint: accounts.freeze
// Spec: Endpoints
// Behavior: Frozen accounts cannot send transactions

test("PROOF-B-056-BLa — Frozen accounts cannot send transactions", async ({ request }) => {
  // Precondition: Account status is 'frozen'
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined();

  // Side-Effect-Check: Read counter BEFORE action
  const { data: before } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  const countBefore = (before as Record<string, unknown>)?.count as number ?? 0;
  // Act
  const { data, status } = await trpcMutation(request, "accounts.freeze", {
    accountId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in accounts.freeze
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  const { data: after } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  const countAfter = (after as Record<string, unknown>)?.count as number ?? 0;
  expect(countAfter).toBe(countBefore + 1);
  // Kills: Not incrementing counter in accounts.freeze
  // Kills: Remove success path in accounts.freeze
  // Kills: Not updating Outgoing transactions from frozen accounts are rejected after cannot send in accounts.freeze
});
test("PROOF-B-056-BLb — Frozen accounts cannot send transactions requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  const { status } = await trpcMutation(request, "accounts.freeze", {
    accountId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from accounts.freeze
});
test("PROOF-B-056-BLc — Frozen accounts cannot send transactions persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined(); // Kills: Don't return id from accounts.freeze
  const { data: fetched, status } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove accounts.list endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === accountId)).toBe(true); // Kills: Don't persist to DB
});

// PROOF-B-057-BL — Business Logic: Frozen accounts can receive transactions
// Risk: high | Endpoint: accounts.freeze
// Spec: Endpoints
// Behavior: Frozen accounts can receive transactions

test("PROOF-B-057-BLa — Frozen accounts can receive transactions", async ({ request }) => {
  // Precondition: Account status is 'frozen'
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined();

  // Side-Effect-Check: Read counter BEFORE action
  const { data: before } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  const countBefore = (before as Record<string, unknown>)?.count as number ?? 0;
  // Act
  const { data, status } = await trpcMutation(request, "accounts.freeze", {
    accountId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in accounts.freeze
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  const { data: after } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  const countAfter = (after as Record<string, unknown>)?.count as number ?? 0;
  expect(countAfter).toBe(countBefore + 1);
  // Kills: Not incrementing counter in accounts.freeze
  // Kills: Remove success path in accounts.freeze
  // Kills: Not updating Incoming transactions to frozen accounts are allowed after can receive in accounts.freeze
});
test("PROOF-B-057-BLb — Frozen accounts can receive transactions requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  const { status } = await trpcMutation(request, "accounts.freeze", {
    accountId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from accounts.freeze
});
test("PROOF-B-057-BLc — Frozen accounts can receive transactions persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined(); // Kills: Don't return id from accounts.freeze
  const { data: fetched, status } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove accounts.list endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === accountId)).toBe(true); // Kills: Don't persist to DB
});

// PROOF-B-060-BL — Business Logic: POST /api/accounts/:id/unfreeze requires admin authorization
// Risk: critical | Endpoint: accounts.unfreeze
// Spec: Endpoints
// Behavior: POST /api/accounts/:id/unfreeze requires admin authorization

test("PROOF-B-060-BLa — POST /api/accounts/:id/unfreeze requires admin authorization", async ({ request }) => {
  // Precondition: User attempts to unfreeze an account
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined();

  // Act
  const { data, status } = await trpcMutation(request, "accounts.unfreeze", {
    accountId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in accounts.unfreeze
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  // Kills: Remove success path in accounts.unfreeze
});
test("PROOF-B-060-BLb — POST /api/accounts/:id/unfreeze requires admin authorization requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  const { status } = await trpcMutation(request, "accounts.unfreeze", {
    accountId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from accounts.unfreeze
});
test("PROOF-B-060-BLc — POST /api/accounts/:id/unfreeze requires admin authorization persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const accountId = created.id as number;
  expect(accountId).toBeDefined(); // Kills: Don't return id from accounts.unfreeze
  const { data: fetched, status } = await trpcQuery(request, "accounts.list",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove accounts.list endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === accountId)).toBe(true); // Kills: Don't persist to DB
});