import { expect, test } from "@playwright/test";
import { trpcMutation } from "../../helpers/api";
import { getCustomerCookie } from "../../helpers/auth";
import { TEST_BANK_ID } from "../../helpers/factories";

let adminCookie: string;

test.beforeAll(async ({ request }) => {
  adminCookie = await getAdminCookie(request);
});

// PROOF-B-004-BOUND — Boundary: Monetary values are stored as EUR cents (integer)
// Risk: medium
// Boundary Field: initialDeposit (number, min: 0, max: 1000000)

const basePayload_PROOF_B_004_BOUND = (boundaryValue: unknown) => ({
    bankId: TEST_BANK_ID,
    customerId: 1,
    accountType: "checking",
    initialDeposit: boundaryValue,
});

test("PROOF-B-004-BOUNDa — initialDeposit=0 (minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.create", basePayload_PROOF_B_004_BOUND(0), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in initialDeposit validation (off-by-one)
});

test("PROOF-B-004-BOUNDb — initialDeposit=1000000 (maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.create", basePayload_PROOF_B_004_BOUND(1000000), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in initialDeposit validation (off-by-one)
});

test("PROOF-B-004-BOUNDc — initialDeposit=-1 (below minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.create", basePayload_PROOF_B_004_BOUND(-1), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});

test("PROOF-B-004-BOUNDd — initialDeposit=1000001 (above maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.create", basePayload_PROOF_B_004_BOUND(1000001), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});

test("PROOF-B-004-BOUNDe — initialDeposit=null", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.create", basePayload_PROOF_B_004_BOUND(null), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});

// PROOF-B-026-BOUND — Boundary: GET /api/accounts/:id returns 404 if account doesn't exist
// Risk: critical

const basePayload_PROOF_B_026_BOUND = (boundaryValue: unknown) => ({
    id: 1,
    role: boundaryValue,
});

test("PROOF-B-026-BOUNDa — role=1 (minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.getById", basePayload_PROOF_B_026_BOUND(1), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in role validation (off-by-one)
});

test("PROOF-B-026-BOUNDb — role=100 (maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.getById", basePayload_PROOF_B_026_BOUND(100), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in role validation (off-by-one)
});

test("PROOF-B-026-BOUNDc — role=0 (below minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.getById", basePayload_PROOF_B_026_BOUND(0), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove role boundary validation
});

test("PROOF-B-026-BOUNDd — role=101 (above maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.getById", basePayload_PROOF_B_026_BOUND(101), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove role boundary validation
});

test("PROOF-B-026-BOUNDe — role=null", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.getById", basePayload_PROOF_B_026_BOUND(null), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove role boundary validation
});

// PROOF-B-032-BOUND — Boundary: POST /api/transactions returns 422 for insufficient balance
// Risk: high
// Boundary Field: amount (number, min: 1, max: 50000000)

const basePayload_PROOF_B_032_BOUND = (boundaryValue: unknown) => ({
    bankId: TEST_BANK_ID,
    fromAccountId: 1,
    toAccountId: 1,
    idempotencyKey: TEST_BANK_ID,
    amount: boundaryValue,
});

test("PROOF-B-032-BOUNDa — amount=1.00 (minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "transactions.create", basePayload_PROOF_B_032_BOUND(1.00), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in amount validation (off-by-one)
});

test("PROOF-B-032-BOUNDb — amount=50000000.00 (maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "transactions.create", basePayload_PROOF_B_032_BOUND(50000000.00), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in amount validation (off-by-one)
});

test("PROOF-B-032-BOUNDc — amount=0.99 (below minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "transactions.create", basePayload_PROOF_B_032_BOUND(0.99), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove amount boundary validation
});

test("PROOF-B-032-BOUNDd — amount=50000000.01 (above maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "transactions.create", basePayload_PROOF_B_032_BOUND(50000000.01), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove amount boundary validation
});

test("PROOF-B-032-BOUNDe — amount=null", async ({ request }) => {
  const { status } = await trpcMutation(request, "transactions.create", basePayload_PROOF_B_032_BOUND(null), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove amount boundary validation
});

// PROOF-B-054-BOUND — Boundary: DELETE /api/accounts/:id returns 422 if account has positive balance
// Risk: high

const basePayload_PROOF_B_054_BOUND = (boundaryValue: unknown) => ({
    id: 1,
    role: boundaryValue,
});

test("PROOF-B-054-BOUNDa — role=1 (minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.delete", basePayload_PROOF_B_054_BOUND(1), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in role validation (off-by-one)
});

test("PROOF-B-054-BOUNDb — role=100 (maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.delete", basePayload_PROOF_B_054_BOUND(100), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in role validation (off-by-one)
});

test("PROOF-B-054-BOUNDc — role=0 (below minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.delete", basePayload_PROOF_B_054_BOUND(0), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove role boundary validation
});

test("PROOF-B-054-BOUNDd — role=101 (above maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.delete", basePayload_PROOF_B_054_BOUND(101), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove role boundary validation
});

test("PROOF-B-054-BOUNDe — role=null", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.delete", basePayload_PROOF_B_054_BOUND(null), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove role boundary validation
});