# TestForge Report v3.0 — BankingCore v2.1

Generated: 2026-03-23 09:56:58 | Spec Type: api-spec | Quality Score: 9.0/10.0

## Verdict

**94/95 proofs passed validation (score: 9.9/10.0)**

| Metric | Value |
|---|---|
| Verdict Score | 9.9/10.0 |
| Behaviors Extracted | 86 |
| API Endpoints Discovered | 13 |
| Coverage | 76% (65/86) |
| Validated Proofs | 94 |
| Discarded Proofs | 1 |
| IDOR Attack Vectors | 6 |
| CSRF Endpoints | 4 |

## LLM Checker Results

| Verdict | Count |
|---|---|
| ✅ Approved | 86 |
| ⚠️ Flagged | 0 |
| ❌ Rejected (hallucinated) | 0 |
| Avg Confidence | 100% |

## Risk Distribution

| Level | Count |
|---|---|
| 🔴 Critical | 32 |
| 🟠 High | 29 |
| 🟡 Medium | 9 |
| 🟢 Low | 16 |

## Ambiguity Gate

### B-017 — ⚠ Reduces Confidence
**Problem:** The specific HTTP status code for 'Customer not found or not in same bank' is not specified.
**Question:** What HTTP status code and error message should be returned if the customer with `customerId` does not exist or does not belong to the same `bankId` during account creation?

### B-056 — ⚠ Reduces Confidence
**Problem:** The specific HTTP status code and error message for 'Attempt to send transaction from frozen account' is not specified.
**Question:** What HTTP status code and error message should be returned if an attempt is made to send a transaction from a frozen account?

## Validated Proofs

### PROOF-B-001-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-002-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-004-BOUND — BOUNDARY
- **File:** `tests/business/boundary.spec.ts`
- **Risk:** medium
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-009-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-009-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-010-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-010-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-011-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-011-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-012-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-012-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-013-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-013-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-014-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-014-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-015-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-015-CONCURRENCY — CONCURRENCY
- **File:** `tests/concurrency/race-conditions.spec.ts`
- **Risk:** high
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-017-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-019-CONCURRENCY — CONCURRENCY
- **File:** `tests/concurrency/race-conditions.spec.ts`
- **Risk:** medium
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-020-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-020-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-021-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-021-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-022-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-022-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-023-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-023-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-025-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-025-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-026-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-026-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-027-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-027-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-028-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-028-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-029-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-029-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-029-CONCURRENCY — CONCURRENCY
- **File:** `tests/concurrency/race-conditions.spec.ts`
- **Risk:** critical
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-030-BOUND — BOUNDARY
- **File:** `tests/business/boundary.spec.ts`
- **Risk:** medium
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-031-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-031-CONCURRENCY — CONCURRENCY
- **File:** `tests/concurrency/race-conditions.spec.ts`
- **Risk:** high
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-033-CONCURRENCY — CONCURRENCY
- **File:** `tests/concurrency/race-conditions.spec.ts`
- **Risk:** medium
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-034-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-036-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-036-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-037-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-038-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-039-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-040-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-041-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-042-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-043-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-044-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-045-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-045-CONCURRENCY — CONCURRENCY
- **File:** `tests/concurrency/race-conditions.spec.ts`
- **Risk:** high
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-046-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-047-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-047-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-048-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-048-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-049-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-049-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-050-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-051-BOUND — BOUNDARY
- **File:** `tests/business/boundary.spec.ts`
- **Risk:** medium
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-053-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-053-IDEMPOTENCY — IDEMPOTENCY
- **File:** `tests/integration/idempotency.spec.ts`
- **Risk:** high
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-054-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-054-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-055-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-056-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-056-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-057-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-057-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-058-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-058-IDEMPOTENCY — IDEMPOTENCY
- **File:** `tests/integration/idempotency.spec.ts`
- **Risk:** high
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-059-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-060-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-060-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-061-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-062-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-063-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-064-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-065-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-066-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-067-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-068-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-069-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-070-DSGVO — DSGVO
- **File:** `tests/compliance/dsgvo.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-071-DSGVO — DSGVO
- **File:** `tests/compliance/dsgvo.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-072-DSGVO — DSGVO
- **File:** `tests/compliance/dsgvo.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-073-DSGVO — DSGVO
- **File:** `tests/compliance/dsgvo.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-074-CSRF — CSRF
- **File:** `tests/security/csrf.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-076-CSRF — CSRF
- **File:** `tests/security/csrf.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-077-CSRF — CSRF
- **File:** `tests/security/csrf.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

## Discarded Proofs (False-Green Detection)

### PROOF-B-075-CSRF — DISCARDED
- **Reason:** `no_side_effect_check`
- **Details:** R4 violation: Security test has no side-effect check. Add DB state verification.

## Uncovered Behaviors

- **B-003**: Accounts belong to exactly one customer
- **B-005**: All endpoints require Authorization: Bearer <jwt> header
- **B-006**: Expired or invalid JWT results in 401
- **B-007**: Missing JWT results in 401
- **B-008**: Rate limit for failed auth attempts
- **B-016**: IBAN is auto-generated and globally unique
- **B-018**: POST /api/accounts returns 400 for invalid accountType
- **B-024**: GET /api/accounts/:id returns 404 if account doesn't exist
- **B-032**: Idempotency key prevents duplicate transactions
- **B-035**: Rate limit for transactions per bank
- **B-052**: DELETE /api/accounts/:id returns 422 if account has pending transactions
- **B-075**: CSRF token obtained via GET /api/auth/csrf-token
- **B-078**: POST /api/webhooks/subscribe registers webhook URL for events
- **B-079**: Webhooks support account.created event
- **B-080**: Webhooks support account.frozen event
- **B-081**: Webhooks support account.closed event
- **B-082**: Webhooks support transaction.completed event
- **B-083**: Webhooks support transaction.reversed event
- **B-084**: Webhooks include HMAC-SHA256 signature in X-Webhook-Signature header
- **B-085**: Webhooks retry with exponential backoff
- **B-086**: Webhooks use X-Webhook-Id header for replay protection

## Getting Started

```bash
npm install
npx playwright install --with-deps chromium
BASE_URL=https://your-staging-url.com npx playwright test --list
BASE_URL=https://your-staging-url.com npx playwright test
```

Red test = Bug found. Green test = Spec correctly implemented. Both are success.
