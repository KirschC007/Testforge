# TestForge Report v3.0 — BankingCore

Generated: 2026-03-23 08:52:00 | Spec Type: api-spec | Quality Score: 8.0/10.0

## Verdict

**131/134 proofs passed validation (score: 9.8/10.0)**

| Metric | Value |
|---|---|
| Verdict Score | 9.8/10.0 |
| Behaviors Extracted | 109 |
| API Endpoints Discovered | 11 |
| Coverage | 83% (90/109) |
| Validated Proofs | 131 |
| Discarded Proofs | 3 |
| IDOR Attack Vectors | 5 |
| CSRF Endpoints | 4 |

## LLM Checker Results

| Verdict | Count |
|---|---|
| ✅ Approved | 109 |
| ⚠️ Flagged | 0 |
| ❌ Rejected (hallucinated) | 0 |
| Avg Confidence | 100% |

## Risk Distribution

| Level | Count |
|---|---|
| 🔴 Critical | 42 |
| 🟠 High | 46 |
| 🟡 Medium | 7 |
| 🟢 Low | 14 |

## Ambiguity Gate

### B-024 — ⚠ Reduces Confidence
**Problem:** The error code for a non-existent customer when creating an account is not specified.
**Question:** What HTTP status code and error message should be returned if the `customerId` does not exist during account creation?

### B-025 — ⚠ Reduces Confidence
**Problem:** The error code for a customer belonging to a different bank when creating an account is not specified.
**Question:** What HTTP status code and error message should be returned if the `customerId` exists but belongs to a different `bankId` than the one in the JWT during account creation?

### B-064 — ⚠ Reduces Confidence
**Problem:** The condition 'already rolled back or never committed' for reversed transactions having no balance change is unclear.
**Question:** How is it determined if a transaction's balance change was 'already rolled back or never committed'? Is this an implicit system behavior or does it depend on the transaction's prior state?

### B-079 — ⚠ Reduces Confidence
**Problem:** The specific error code for a frozen account attempting to send a transaction is not specified.
**Question:** What HTTP status code and error message should be returned if a frozen account attempts to send a transaction?

## Validated Proofs

### PROOF-B-002-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-002-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-009-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-014-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-014-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-015-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-015-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-016-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-016-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-017-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-017-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-018-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-018-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-019-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-019-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-020-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-020-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-021-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-021-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-022-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-022-CONCURRENCY — CONCURRENCY
- **File:** `tests/concurrency/race-conditions.spec.ts`
- **Risk:** high
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-025-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-025-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-026-BOUND — BOUNDARY
- **File:** `tests/business/boundary.spec.ts`
- **Risk:** medium
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-027-BOUND — BOUNDARY
- **File:** `tests/business/boundary.spec.ts`
- **Risk:** medium
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-027-CONCURRENCY — CONCURRENCY
- **File:** `tests/concurrency/race-conditions.spec.ts`
- **Risk:** medium
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-028-BOUND — BOUNDARY
- **File:** `tests/business/boundary.spec.ts`
- **Risk:** medium
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-028-CONCURRENCY — CONCURRENCY
- **File:** `tests/concurrency/race-conditions.spec.ts`
- **Risk:** medium
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-029-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-029-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-030-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-030-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-031-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-031-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-032-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-032-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-033-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-033-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-034-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-034-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-035-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-035-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-037-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-037-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-038-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-038-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-039-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-039-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-040-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-040-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-041-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-041-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-042-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-042-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-043-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-043-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-044-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-045-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-046-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-046-CONCURRENCY — CONCURRENCY
- **File:** `tests/concurrency/race-conditions.spec.ts`
- **Risk:** high
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-050-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-051-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-053-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-053-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-054-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-055-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-056-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-057-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-058-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-059-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-060-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-061-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-062-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-062-CONCURRENCY — CONCURRENCY
- **File:** `tests/concurrency/race-conditions.spec.ts`
- **Risk:** high
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-063-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-063-IDEMPOTENCY — IDEMPOTENCY
- **File:** `tests/integration/idempotency.spec.ts`
- **Risk:** high
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-064-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-064-IDEMPOTENCY — IDEMPOTENCY
- **File:** `tests/integration/idempotency.spec.ts`
- **Risk:** high
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-065-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-066-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-066-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-067-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-067-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-068-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-068-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-069-IDOR — IDOR
- **File:** `tests/security/idor.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-069-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-070-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-070-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-071-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-072-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-073-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-074-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-075-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-076-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-076-IDEMPOTENCY — IDEMPOTENCY
- **File:** `tests/integration/idempotency.spec.ts`
- **Risk:** high
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-077-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-077-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-078-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-079-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-080-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-081-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-081-IDEMPOTENCY — IDEMPOTENCY
- **File:** `tests/integration/idempotency.spec.ts`
- **Risk:** high
- **Mutation Score:** 33%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-082-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-083-BL — BUSINESS_LOGIC
- **File:** `tests/business/logic.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-083-AUTHMATRIX — AUTH_MATRIX
- **File:** `tests/security/auth-matrix.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-084-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-085-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-086-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-087-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-088-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-089-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-090-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-091-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-092-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-093-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-094-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-095-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-096-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-097-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-098-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-099-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-100-STATUS — STATUS_TRANSITION
- **File:** `tests/integration/status-transitions.spec.ts`
- **Risk:** high
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-101-DSGVO — DSGVO
- **File:** `tests/compliance/dsgvo.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-102-DSGVO — DSGVO
- **File:** `tests/compliance/dsgvo.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-103-DSGVO — DSGVO
- **File:** `tests/compliance/dsgvo.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-104-DSGVO — DSGVO
- **File:** `tests/compliance/dsgvo.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-105-DSGVO — DSGVO
- **File:** `tests/compliance/dsgvo.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-106-CSRF — CSRF
- **File:** `tests/security/csrf.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-108-CSRF — CSRF
- **File:** `tests/security/csrf.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

### PROOF-B-109-CSRF — CSRF
- **File:** `tests/security/csrf.spec.ts`
- **Risk:** critical
- **Mutation Score:** 100%
- **Validation:** ✓ R1: No if-wrapper assertions, ✓ R2: Has value assertions, ✓ R3: No broad status codes, ✓ R4: Has side-effect check, ✓ R5: Has positive control, ✓ R6: Baseline present, ✓ R8: Preconditions verified, ✓ R7: Has mutation-kill comments, ✓ R7b: No fake IDOR IDs

## Discarded Proofs (False-Green Detection)

### PROOF-B-005-BOUND — DISCARDED
- **Reason:** `no_mutation_kill`
- **Details:** R7 violation: No '// Kills:' comment found. Every assertion must explain which mutation it kills.

### PROOF-B-006-BOUND — DISCARDED
- **Reason:** `no_mutation_kill`
- **Details:** R7 violation: No '// Kills:' comment found. Every assertion must explain which mutation it kills.

### PROOF-B-107-CSRF — DISCARDED
- **Reason:** `no_side_effect_check`
- **Details:** R4 violation: Security test has no side-effect check. Add DB state verification.

## Uncovered Behaviors

- **B-001**: BankingCore is a multi-tenant banking backend
- **B-003**: Customers belong to exactly one bank
- **B-004**: Accounts belong to exactly one customer
- **B-005**: All monetary values are in EUR cents (integer)
- **B-006**: No monetary values are floating point
- **B-007**: All endpoints require Authorization: Bearer <jwt> header
- **B-008**: JWT contains userId
- **B-010**: JWT contains role
- **B-011**: Expired or invalid JWT returns 401
- **B-012**: Missing JWT returns 401
- **B-013**: Rate limit: max 5 failed auth attempts per minute per IP
- **B-023**: IBAN is auto-generated and globally unique
- **B-024**: Customer with customerId must exist for account creation
- **B-036**: GET /api/accounts/:id returns 404 if account doesn't exist
- **B-047**: idempotencyKey prevents duplicate transactions
- **B-048**: Same idempotencyKey returns original result
- **B-049**: POST /api/transactions returns 400 SAME_ACCOUNT if fromAccountId == toAccountId
- **B-052**: Rate limit: max 20 transactions per minute per bank
- **B-107**: CSRF Token obtained via GET /api/auth/csrf-token

## Getting Started

```bash
npm install
npx playwright install --with-deps chromium
BASE_URL=https://your-staging-url.com npx playwright test --list
BASE_URL=https://your-staging-url.com npx playwright test
```

Red test = Bug found. Green test = Spec correctly implemented. Both are success.
