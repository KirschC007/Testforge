import { expect, test } from "@playwright/test";
import { BASE_URL, trpcQuery } from "../../helpers/api";
import { getAdminCookie, getAdvisorCookie, getCustomerCookie } from "../../helpers/auth";
import { TEST_BANK_ID } from "../../helpers/factories";

let adminCookie: string;

test.beforeAll(async ({ request }) => {
  adminCookie = await getAdminCookie(request);
});

// Proof: PROOF-B-002-AUTHMATRIX
// Behavior: Each bank (tenant) is isolated by bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_002_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    customerId: "1",
    accountType: "\"checking\"",
    initialDeposit: "1",
  };
}
test.describe("Auth Matrix: Each bank (tenant) is isolated by bankId", () => {
  test("admin must be able to is isolated by bankId", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_002_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_002_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to is isolated by bankId", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_002_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to is isolated by bankId", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_002_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant is isolated by must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_002_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.create", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.create", async ({ request }) => {
    // Kills: Remove role check in accounts.create
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_002_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.create — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access bankId", async ({ request }) => {
    // Kills: Allow lower-privileged role to access bankId
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_002_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access bankId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access bankId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to is isolated by bankId", async ({ request }) => {
    // Kills: customer should not be able to is isolated by bankId
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_002_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to is isolated by bankId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to is isolated by bankId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to is isolated by bankId", async ({ request }) => {
    // Kills: advisor should not be able to is isolated by bankId
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_002_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to is isolated by bankId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to is isolated by bankId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-014-AUTHMATRIX
// Behavior: Customer role can only access own accounts
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_014_AUTHMATRIX() {
  return {
    id: "1",
  };
}
test.describe("Auth Matrix: Customer role can only access own accounts", () => {
  test("admin must be able to can only access own accounts", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_014_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_014_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to can only access own accounts", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_014_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to can only access own accounts", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_014_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant can only access must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_014_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.getById", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.getById", async ({ request }) => {
    // Kills: Remove role check in accounts.getById
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_014_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.getById — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access own accounts", async ({ request }) => {
    // Kills: Allow lower-privileged role to access own accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_014_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access own accounts — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access own accounts — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to can only access own accounts", async ({ request }) => {
    // Kills: customer should not be able to can only access own accounts
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_014_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to can only access own accounts — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to can only access own accounts — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to can only access own accounts", async ({ request }) => {
    // Kills: advisor should not be able to can only access own accounts
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_014_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to can only access own accounts — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to can only access own accounts — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-015-AUTHMATRIX
// Behavior: Customer role can only access own transactions
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_015_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    customerId: "1",
    accountType: "\"checking\"",
    initialDeposit: "1",
  };
}
test.describe("Auth Matrix: Customer role can only access own transactions", () => {
  test("admin must be able to can only access own transactions", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_015_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_015_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to can only access own transactions", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_015_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to can only access own transactions", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_015_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant can only access must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_015_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.create", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.create", async ({ request }) => {
    // Kills: Remove role check in accounts.create
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_015_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.create — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access own transactions", async ({ request }) => {
    // Kills: Allow lower-privileged role to access own transactions
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_015_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access own transactions — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access own transactions — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to can only access own transactions", async ({ request }) => {
    // Kills: customer should not be able to can only access own transactions
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_015_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to can only access own transactions — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to can only access own transactions — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to can only access own transactions", async ({ request }) => {
    // Kills: advisor should not be able to can only access own transactions
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_015_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to can only access own transactions — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to can only access own transactions — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-016-AUTHMATRIX
// Behavior: Advisor role can access all accounts within their bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_016_AUTHMATRIX() {
  return {
    id: "1",
  };
}
test.describe("Auth Matrix: Advisor role can access all accounts within their bankId", () => {
  test("admin must be able to can access all accounts within their `bankId`", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_016_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_016_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to can access all accounts within their `bankId`", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_016_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to can access all accounts within their `bankId`", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_016_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant can access must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_016_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.getById", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.getById", async ({ request }) => {
    // Kills: Remove role check in accounts.getById
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_016_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.getById — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access all accounts within their `bankId`", async ({ request }) => {
    // Kills: Allow lower-privileged role to access all accounts within their `bankId`
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_016_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access all accounts within their `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access all accounts within their `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to can access all accounts within their `bankId`", async ({ request }) => {
    // Kills: customer should not be able to can access all accounts within their `bankId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_016_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to can access all accounts within their `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to can access all accounts within their `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to can access all accounts within their `bankId`", async ({ request }) => {
    // Kills: advisor should not be able to can access all accounts within their `bankId`
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_016_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to can access all accounts within their `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to can access all accounts within their `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-017-AUTHMATRIX
// Behavior: Admin role can access everything within their bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_017_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    customerId: "1",
    accountType: "\"checking\"",
    initialDeposit: "1",
  };
}
test.describe("Auth Matrix: Admin role can access everything within their bankId", () => {
  test("admin must be able to can access everything within their `bankId`", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_017_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_017_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to can access everything within their `bankId`", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_017_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to can access everything within their `bankId`", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_017_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant can access must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_017_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.create", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.create", async ({ request }) => {
    // Kills: Remove role check in accounts.create
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_017_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.create — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access everything within their `bankId`", async ({ request }) => {
    // Kills: Allow lower-privileged role to access everything within their `bankId`
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_017_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access everything within their `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access everything within their `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to can access everything within their `bankId`", async ({ request }) => {
    // Kills: customer should not be able to can access everything within their `bankId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_017_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to can access everything within their `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to can access everything within their `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to can access everything within their `bankId`", async ({ request }) => {
    // Kills: advisor should not be able to can access everything within their `bankId`
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_017_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to can access everything within their `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to can access everything within their `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-018-AUTHMATRIX
// Behavior: Admin role cannot access other banks
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_018_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    customerId: "1",
    accountType: "\"checking\"",
    initialDeposit: "1",
  };
}
test.describe("Auth Matrix: Admin role cannot access other banks", () => {
  test("admin must be able to cannot access other banks", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_018_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_018_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to cannot access other banks", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_018_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to cannot access other banks", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_018_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant cannot access must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_018_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.create", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.create", async ({ request }) => {
    // Kills: Remove role check in accounts.create
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_018_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.create — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access other banks", async ({ request }) => {
    // Kills: Allow lower-privileged role to access other banks
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_018_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access other banks — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access other banks — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to cannot access other banks", async ({ request }) => {
    // Kills: customer should not be able to cannot access other banks
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_018_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to cannot access other banks — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to cannot access other banks — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to cannot access other banks", async ({ request }) => {
    // Kills: advisor should not be able to cannot access other banks
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_018_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to cannot access other banks — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to cannot access other banks — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-019-AUTHMATRIX
// Behavior: POST /api/accounts requires advisor or admin authorization
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_019_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    customerId: "1",
    accountType: "\"checking\"",
    initialDeposit: "1",
  };
}
test.describe("Auth Matrix: POST /api/accounts requires advisor or admin authorization", () => {
  test("admin must be able to requires advisor or admin authorization", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_019_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_019_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to requires advisor or admin authorization", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_019_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to requires advisor or admin authorization", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_019_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant requires must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_019_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.create", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.create", async ({ request }) => {
    // Kills: Remove role check in accounts.create
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_019_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.create — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access advisor or admin authorization", async ({ request }) => {
    // Kills: Allow lower-privileged role to access advisor or admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_019_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access advisor or admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access advisor or admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to requires advisor or admin authorization", async ({ request }) => {
    // Kills: customer should not be able to requires advisor or admin authorization
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_019_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to requires advisor or admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to requires advisor or admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to requires advisor or admin authorization", async ({ request }) => {
    // Kills: advisor should not be able to requires advisor or admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_019_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to requires advisor or admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to requires advisor or admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-020-AUTHMATRIX
// Behavior: bankId in body must match JWT bankId for account creation
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_020_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    customerId: "1",
    accountType: "\"checking\"",
    initialDeposit: "1",
  };
}
test.describe("Auth Matrix: bankId in body must match JWT bankId for account creation", () => {
  test("admin must be able to must match JWT `bankId`", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_020_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_020_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to must match JWT `bankId`", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_020_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to must match JWT `bankId`", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_020_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant must match must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_020_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.create", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.create", async ({ request }) => {
    // Kills: Remove role check in accounts.create
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_020_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.create — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access JWT `bankId`", async ({ request }) => {
    // Kills: Allow lower-privileged role to access JWT `bankId`
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_020_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access JWT `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access JWT `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to must match JWT `bankId`", async ({ request }) => {
    // Kills: customer should not be able to must match JWT `bankId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_020_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to must match JWT `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to must match JWT `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to must match JWT `bankId`", async ({ request }) => {
    // Kills: advisor should not be able to must match JWT `bankId`
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_020_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to must match JWT `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to must match JWT `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-021-AUTHMATRIX
// Behavior: Cross-tenant account creation returns 403
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_021_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    customerId: "1",
    accountType: "\"checking\"",
    initialDeposit: "1",
  };
}
test.describe("Auth Matrix: Cross-tenant account creation returns 403", () => {
  test("admin must be able to returns 403 cross-tenant account creation", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_021_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_021_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to returns 403 cross-tenant account creation", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_021_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to returns 403 cross-tenant account creation", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_021_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant returns 403 must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_021_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.create", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.create", async ({ request }) => {
    // Kills: Remove role check in accounts.create
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_021_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.create — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access cross-tenant account creation", async ({ request }) => {
    // Kills: Allow lower-privileged role to access cross-tenant account creation
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_021_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access cross-tenant account creation — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access cross-tenant account creation — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to returns 403 cross-tenant account creation", async ({ request }) => {
    // Kills: customer should not be able to returns 403 cross-tenant account creation
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_021_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to returns 403 cross-tenant account creation — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to returns 403 cross-tenant account creation — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to returns 403 cross-tenant account creation", async ({ request }) => {
    // Kills: advisor should not be able to returns 403 cross-tenant account creation
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_021_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to returns 403 cross-tenant account creation — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to returns 403 cross-tenant account creation — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-024-AUTHMATRIX
// Behavior: Customer with customerId must exist and belong to same bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_024_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    customerId: "1",
    accountType: "\"checking\"",
    initialDeposit: "1",
  };
}
test.describe("Auth Matrix: Customer with customerId must exist and belong to same bankId", () => {
  test("admin must be able to must exist and belong to same `bankId`", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_024_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_024_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to must exist and belong to same `bankId`", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_024_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to must exist and belong to same `bankId`", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_024_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant must exist and belong to must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_024_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.create", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.create", async ({ request }) => {
    // Kills: Remove role check in accounts.create
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_024_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.create — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access same `bankId`", async ({ request }) => {
    // Kills: Allow lower-privileged role to access same `bankId`
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_024_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access same `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access same `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to must exist and belong to same `bankId`", async ({ request }) => {
    // Kills: customer should not be able to must exist and belong to same `bankId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_024_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to must exist and belong to same `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to must exist and belong to same `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to must exist and belong to same `bankId`", async ({ request }) => {
    // Kills: advisor should not be able to must exist and belong to same `bankId`
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.create", basePayload_PROOF_B_024_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to must exist and belong to same `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to must exist and belong to same `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-027-AUTHMATRIX
// Behavior: GET /api/accounts: Customer sees only own accounts
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_027_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: GET /api/accounts: Customer sees only own accounts", () => {
  test("admin must be able to sees only own accounts", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_027_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_027_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to sees only own accounts", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_027_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to sees only own accounts", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_027_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant sees only must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_027_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.list", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.list", async ({ request }) => {
    // Kills: Remove role check in accounts.list
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_027_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.list — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access own accounts", async ({ request }) => {
    // Kills: Allow lower-privileged role to access own accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_027_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access own accounts — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access own accounts — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to sees only own accounts", async ({ request }) => {
    // Kills: customer should not be able to sees only own accounts
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_027_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to sees only own accounts — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to sees only own accounts — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to sees only own accounts", async ({ request }) => {
    // Kills: advisor should not be able to sees only own accounts
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_027_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to sees only own accounts — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to sees only own accounts — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-028-AUTHMATRIX
// Behavior: GET /api/accounts: Advisor/admin sees all accounts within bank
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_028_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: GET /api/accounts: Advisor/admin sees all accounts within bank", () => {
  test("admin must be able to sees all accounts within bank", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_028_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_028_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to sees all accounts within bank", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_028_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to sees all accounts within bank", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_028_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant sees all must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_028_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.list", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.list", async ({ request }) => {
    // Kills: Remove role check in accounts.list
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_028_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.list — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access accounts within bank", async ({ request }) => {
    // Kills: Allow lower-privileged role to access accounts within bank
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_028_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access accounts within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access accounts within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to sees all accounts within bank", async ({ request }) => {
    // Kills: customer should not be able to sees all accounts within bank
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_028_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to sees all accounts within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to sees all accounts within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to sees all accounts within bank", async ({ request }) => {
    // Kills: advisor should not be able to sees all accounts within bank
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_028_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to sees all accounts within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to sees all accounts within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-029-AUTHMATRIX
// Behavior: Customer role automatically filters accounts to own customerId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_029_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: Customer role automatically filters accounts to own customerId", () => {
  test("admin must be able to is automatically filtered to own `customerId`", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_029_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_029_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to is automatically filtered to own `customerId`", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_029_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to is automatically filtered to own `customerId`", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_029_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant is automatically filtered to must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_029_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.list", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.list", async ({ request }) => {
    // Kills: Remove role check in accounts.list
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_029_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.list — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access own `customerId`", async ({ request }) => {
    // Kills: Allow lower-privileged role to access own `customerId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_029_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access own `customerId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access own `customerId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to is automatically filtered to own `customerId`", async ({ request }) => {
    // Kills: customer should not be able to is automatically filtered to own `customerId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_029_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to is automatically filtered to own `customerId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to is automatically filtered to own `customerId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to is automatically filtered to own `customerId`", async ({ request }) => {
    // Kills: advisor should not be able to is automatically filtered to own `customerId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_029_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to is automatically filtered to own `customerId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to is automatically filtered to own `customerId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-030-AUTHMATRIX
// Behavior: Advisor/admin can filter accounts by customerId or see all
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_030_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: Advisor/admin can filter accounts by customerId or see all", () => {
  test("admin must be able to can filter accounts by `customerId` or see all", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_030_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_030_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to can filter accounts by `customerId` or see all", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_030_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to can filter accounts by `customerId` or see all", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_030_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant can filter accounts by must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_030_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.list", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.list", async ({ request }) => {
    // Kills: Remove role check in accounts.list
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_030_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.list — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access `customerId` or see all", async ({ request }) => {
    // Kills: Allow lower-privileged role to access `customerId` or see all
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_030_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access `customerId` or see all — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access `customerId` or see all — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to can filter accounts by `customerId` or see all", async ({ request }) => {
    // Kills: customer should not be able to can filter accounts by `customerId` or see all
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_030_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to can filter accounts by `customerId` or see all — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to can filter accounts by `customerId` or see all — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to can filter accounts by `customerId` or see all", async ({ request }) => {
    // Kills: advisor should not be able to can filter accounts by `customerId` or see all
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_030_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to can filter accounts by `customerId` or see all — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to can filter accounts by `customerId` or see all — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-031-AUTHMATRIX
// Behavior: GET /api/accounts: bankId must match JWT bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_031_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: GET /api/accounts: bankId must match JWT bankId", () => {
  test("admin must be able to must match JWT `bankId`", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_031_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_031_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to must match JWT `bankId`", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_031_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to must match JWT `bankId`", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_031_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant must match must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_031_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.list", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.list", async ({ request }) => {
    // Kills: Remove role check in accounts.list
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_031_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.list — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access JWT `bankId`", async ({ request }) => {
    // Kills: Allow lower-privileged role to access JWT `bankId`
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_031_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access JWT `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access JWT `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to must match JWT `bankId`", async ({ request }) => {
    // Kills: customer should not be able to must match JWT `bankId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_031_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to must match JWT `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to must match JWT `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to must match JWT `bankId`", async ({ request }) => {
    // Kills: advisor should not be able to must match JWT `bankId`
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_031_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to must match JWT `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to must match JWT `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-032-AUTHMATRIX
// Behavior: Cross-tenant account listing returns 403 with empty data
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_032_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: Cross-tenant account listing returns 403 with empty data", () => {
  test("admin must be able to returns 403 with empty data cross-tenant account listing", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_032_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_032_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to returns 403 with empty data cross-tenant account listing", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_032_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to returns 403 with empty data cross-tenant account listing", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_032_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant returns 403 with empty data must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_032_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.list", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.list", async ({ request }) => {
    // Kills: Remove role check in accounts.list
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_032_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.list — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access cross-tenant account listing", async ({ request }) => {
    // Kills: Allow lower-privileged role to access cross-tenant account listing
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_032_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access cross-tenant account listing — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access cross-tenant account listing — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to returns 403 with empty data cross-tenant account listing", async ({ request }) => {
    // Kills: customer should not be able to returns 403 with empty data cross-tenant account listing
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_032_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to returns 403 with empty data cross-tenant account listing — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to returns 403 with empty data cross-tenant account listing — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to returns 403 with empty data cross-tenant account listing", async ({ request }) => {
    // Kills: advisor should not be able to returns 403 with empty data cross-tenant account listing
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.list", basePayload_PROOF_B_032_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to returns 403 with empty data cross-tenant account listing — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to returns 403 with empty data cross-tenant account listing — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-034-AUTHMATRIX
// Behavior: GET /api/accounts/:id returns 403 if account belongs to different bank
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_034_AUTHMATRIX() {
  return {
    id: "1",
  };
}
test.describe("Auth Matrix: GET /api/accounts/:id returns 403 if account belongs to different bank", () => {
  test("admin must be able to returns 403 if account belongs to different bank", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_034_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_034_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to returns 403 if account belongs to different bank", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_034_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to returns 403 if account belongs to different bank", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_034_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant returns 403 must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_034_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.getById", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.getById", async ({ request }) => {
    // Kills: Remove role check in accounts.getById
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_034_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.getById — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access if account belongs to different bank", async ({ request }) => {
    // Kills: Allow lower-privileged role to access if account belongs to different bank
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_034_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access if account belongs to different bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access if account belongs to different bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to returns 403 if account belongs to different bank", async ({ request }) => {
    // Kills: customer should not be able to returns 403 if account belongs to different bank
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_034_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to returns 403 if account belongs to different bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to returns 403 if account belongs to different bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to returns 403 if account belongs to different bank", async ({ request }) => {
    // Kills: advisor should not be able to returns 403 if account belongs to different bank
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_034_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to returns 403 if account belongs to different bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to returns 403 if account belongs to different bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-035-AUTHMATRIX
// Behavior: GET /api/accounts/:id returns 403 if customer role and account.customerId !== jwt.userId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_035_AUTHMATRIX() {
  return {
    id: "1",
  };
}
test.describe("Auth Matrix: GET /api/accounts/:id returns 403 if customer role and account.customerId !== jwt.userId", () => {
  test("admin must be able to returns 403 if customer role and `account.customerId !== jwt.userId`", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_035_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_035_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to returns 403 if customer role and `account.customerId !== jwt.userId`", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_035_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to returns 403 if customer role and `account.customerId !== jwt.userId`", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_035_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant returns 403 must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_035_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.getById", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.getById", async ({ request }) => {
    // Kills: Remove role check in accounts.getById
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_035_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.getById — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access if customer role and `account.customerId !== jwt.userId`", async ({ request }) => {
    // Kills: Allow lower-privileged role to access if customer role and `account.customerId !== jwt.userId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_035_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access if customer role and `account.customerId !== jwt.userId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access if customer role and `account.customerId !== jwt.userId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to returns 403 if customer role and `account.customerId !== jwt.userId`", async ({ request }) => {
    // Kills: customer should not be able to returns 403 if customer role and `account.customerId !== jwt.userId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_035_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to returns 403 if customer role and `account.customerId !== jwt.userId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to returns 403 if customer role and `account.customerId !== jwt.userId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to returns 403 if customer role and `account.customerId !== jwt.userId`", async ({ request }) => {
    // Kills: advisor should not be able to returns 403 if customer role and `account.customerId !== jwt.userId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.getById", basePayload_PROOF_B_035_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to returns 403 if customer role and `account.customerId !== jwt.userId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to returns 403 if customer role and `account.customerId !== jwt.userId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-036-AUTHMATRIX
// Behavior: POST /api/transactions requires advisor or admin authorization
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_036_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    fromAccountId: "1",
    toAccountId: "1",
    amount: "1",
    description: "\"Test description\"",
    idempotencyKey: TEST_BANK_ID,
  };
}
test.describe("Auth Matrix: POST /api/transactions requires advisor or admin authorization", () => {
  test("admin must be able to requires advisor or admin authorization", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_036_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_036_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to requires advisor or admin authorization", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_036_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to requires advisor or admin authorization", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_036_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant requires must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_036_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "transactions.create", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in transactions.create", async ({ request }) => {
    // Kills: Remove role check in transactions.create
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_036_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in transactions.create — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access advisor or admin authorization", async ({ request }) => {
    // Kills: Allow lower-privileged role to access advisor or admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_036_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access advisor or admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access advisor or admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to requires advisor or admin authorization", async ({ request }) => {
    // Kills: customer should not be able to requires advisor or admin authorization
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_036_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to requires advisor or admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to requires advisor or admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to requires advisor or admin authorization", async ({ request }) => {
    // Kills: advisor should not be able to requires advisor or admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_036_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to requires advisor or admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to requires advisor or admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-037-AUTHMATRIX
// Behavior: bankId in transaction body must match JWT bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_037_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    fromAccountId: "1",
    toAccountId: "1",
    amount: "1",
    description: "\"Test description\"",
    idempotencyKey: TEST_BANK_ID,
  };
}
test.describe("Auth Matrix: bankId in transaction body must match JWT bankId", () => {
  test("admin must be able to must match JWT `bankId`", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_037_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_037_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to must match JWT `bankId`", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_037_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to must match JWT `bankId`", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_037_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant must match must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_037_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "transactions.create", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in transactions.create", async ({ request }) => {
    // Kills: Remove role check in transactions.create
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_037_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in transactions.create — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access JWT `bankId`", async ({ request }) => {
    // Kills: Allow lower-privileged role to access JWT `bankId`
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_037_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access JWT `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access JWT `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to must match JWT `bankId`", async ({ request }) => {
    // Kills: customer should not be able to must match JWT `bankId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_037_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to must match JWT `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to must match JWT `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to must match JWT `bankId`", async ({ request }) => {
    // Kills: advisor should not be able to must match JWT `bankId`
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_037_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to must match JWT `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to must match JWT `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-038-AUTHMATRIX
// Behavior: Cross-tenant transaction creation returns 403
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_038_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    fromAccountId: "1",
    toAccountId: "1",
    amount: "1",
    description: "\"Test description\"",
    idempotencyKey: TEST_BANK_ID,
  };
}
test.describe("Auth Matrix: Cross-tenant transaction creation returns 403", () => {
  test("admin must be able to returns 403 cross-tenant transaction creation", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_038_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_038_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to returns 403 cross-tenant transaction creation", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_038_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to returns 403 cross-tenant transaction creation", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_038_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant returns 403 must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_038_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "transactions.create", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in transactions.create", async ({ request }) => {
    // Kills: Remove role check in transactions.create
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_038_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in transactions.create — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access cross-tenant transaction creation", async ({ request }) => {
    // Kills: Allow lower-privileged role to access cross-tenant transaction creation
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_038_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access cross-tenant transaction creation — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access cross-tenant transaction creation — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to returns 403 cross-tenant transaction creation", async ({ request }) => {
    // Kills: customer should not be able to returns 403 cross-tenant transaction creation
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_038_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to returns 403 cross-tenant transaction creation — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to returns 403 cross-tenant transaction creation — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to returns 403 cross-tenant transaction creation", async ({ request }) => {
    // Kills: advisor should not be able to returns 403 cross-tenant transaction creation
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_038_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to returns 403 cross-tenant transaction creation — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to returns 403 cross-tenant transaction creation — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-039-AUTHMATRIX
// Behavior: fromAccountId and toAccountId must belong to same bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_039_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    fromAccountId: "1",
    toAccountId: "1",
    amount: "1",
    description: "\"Test description\"",
    idempotencyKey: TEST_BANK_ID,
  };
}
test.describe("Auth Matrix: fromAccountId and toAccountId must belong to same bankId", () => {
  test("admin must be able to must belong to same `bankId`", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_039_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_039_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to must belong to same `bankId`", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_039_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to must belong to same `bankId`", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_039_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant must belong to must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_039_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "transactions.create", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in transactions.create", async ({ request }) => {
    // Kills: Remove role check in transactions.create
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_039_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in transactions.create — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access same `bankId`", async ({ request }) => {
    // Kills: Allow lower-privileged role to access same `bankId`
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_039_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access same `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access same `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to must belong to same `bankId`", async ({ request }) => {
    // Kills: customer should not be able to must belong to same `bankId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_039_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to must belong to same `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to must belong to same `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to must belong to same `bankId`", async ({ request }) => {
    // Kills: advisor should not be able to must belong to same `bankId`
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_039_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to must belong to same `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to must belong to same `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-040-AUTHMATRIX
// Behavior: Transaction creation returns 403 if fromAccountId and toAccountId do not belong to same bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_040_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    fromAccountId: "1",
    toAccountId: "1",
    amount: "1",
    description: "\"Test description\"",
    idempotencyKey: TEST_BANK_ID,
  };
}
test.describe("Auth Matrix: Transaction creation returns 403 if fromAccountId and toAccountId do not belong to same bankId", () => {
  test("admin must be able to returns 403 if `fromAccountId` and `toAccountId` do not belong to same `bankId`", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_040_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_040_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to returns 403 if `fromAccountId` and `toAccountId` do not belong to same `bankId`", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_040_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to returns 403 if `fromAccountId` and `toAccountId` do not belong to same `bankId`", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_040_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant returns 403 must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_040_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "transactions.create", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in transactions.create", async ({ request }) => {
    // Kills: Remove role check in transactions.create
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_040_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in transactions.create — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access if `fromAccountId` and `toAccountId` do not belong to same `bankId`", async ({ request }) => {
    // Kills: Allow lower-privileged role to access if `fromAccountId` and `toAccountId` do not belong to same `bankId`
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_040_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access if `fromAccountId` and `toAccountId` do not belong to same `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access if `fromAccountId` and `toAccountId` do not belong to same `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to returns 403 if `fromAccountId` and `toAccountId` do not belong to same `bankId`", async ({ request }) => {
    // Kills: customer should not be able to returns 403 if `fromAccountId` and `toAccountId` do not belong to same `bankId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_040_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to returns 403 if `fromAccountId` and `toAccountId` do not belong to same `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to returns 403 if `fromAccountId` and `toAccountId` do not belong to same `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to returns 403 if `fromAccountId` and `toAccountId` do not belong to same `bankId`", async ({ request }) => {
    // Kills: advisor should not be able to returns 403 if `fromAccountId` and `toAccountId` do not belong to same `bankId`
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.create", basePayload_PROOF_B_040_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to returns 403 if `fromAccountId` and `toAccountId` do not belong to same `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to returns 403 if `fromAccountId` and `toAccountId` do not belong to same `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-048-AUTHMATRIX
// Behavior: PATCH /api/transactions/:id/status requires admin authorization
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_048_AUTHMATRIX() {
  return {
    id: "1",
    status: "\"processing\"",
  };
}
test.describe("Auth Matrix: PATCH /api/transactions/:id/status requires admin authorization", () => {
  test("admin must be able to requires admin authorization", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.status", basePayload_PROOF_B_048_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "transactions.status", basePayload_PROOF_B_048_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.status", basePayload_PROOF_B_048_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.status", basePayload_PROOF_B_048_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant requires must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_048_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "transactions.status", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in transactions.status", async ({ request }) => {
    // Kills: Remove role check in transactions.status
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.status", basePayload_PROOF_B_048_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in transactions.status — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access admin authorization", async ({ request }) => {
    // Kills: Allow lower-privileged role to access admin authorization
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.status", basePayload_PROOF_B_048_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to requires admin authorization", async ({ request }) => {
    // Kills: customer should not be able to requires admin authorization
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.status", basePayload_PROOF_B_048_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to requires admin authorization", async ({ request }) => {
    // Kills: advisor should not be able to requires admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.status", basePayload_PROOF_B_048_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-054-AUTHMATRIX
// Behavior: GET /api/transactions: Customer sees only own transactions
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_054_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    accountId: "1",
    status: "\"pending\"",
    fromDate: "tomorrowStr()",
    toDate: "tomorrowStr()",
  };
}
test.describe("Auth Matrix: GET /api/transactions: Customer sees only own transactions", () => {
  test("admin must be able to sees only own transactions", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_054_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_054_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to sees only own transactions", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_054_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to sees only own transactions", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_054_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant sees only must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_054_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "transactions.list", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in transactions.list", async ({ request }) => {
    // Kills: Remove role check in transactions.list
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_054_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in transactions.list — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access own transactions", async ({ request }) => {
    // Kills: Allow lower-privileged role to access own transactions
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_054_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access own transactions — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access own transactions — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to sees only own transactions", async ({ request }) => {
    // Kills: customer should not be able to sees only own transactions
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_054_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to sees only own transactions — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to sees only own transactions — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to sees only own transactions", async ({ request }) => {
    // Kills: advisor should not be able to sees only own transactions
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_054_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to sees only own transactions — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to sees only own transactions — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-055-AUTHMATRIX
// Behavior: GET /api/transactions: Advisor/admin sees all transactions within bank
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_055_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    accountId: "1",
    status: "\"pending\"",
    fromDate: "tomorrowStr()",
    toDate: "tomorrowStr()",
  };
}
test.describe("Auth Matrix: GET /api/transactions: Advisor/admin sees all transactions within bank", () => {
  test("admin must be able to sees all transactions within bank", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_055_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_055_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to sees all transactions within bank", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_055_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to sees all transactions within bank", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_055_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant sees all must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_055_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "transactions.list", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in transactions.list", async ({ request }) => {
    // Kills: Remove role check in transactions.list
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_055_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in transactions.list — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access transactions within bank", async ({ request }) => {
    // Kills: Allow lower-privileged role to access transactions within bank
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_055_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access transactions within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access transactions within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to sees all transactions within bank", async ({ request }) => {
    // Kills: customer should not be able to sees all transactions within bank
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_055_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to sees all transactions within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to sees all transactions within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to sees all transactions within bank", async ({ request }) => {
    // Kills: advisor should not be able to sees all transactions within bank
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_055_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to sees all transactions within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to sees all transactions within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-056-AUTHMATRIX
// Behavior: GET /api/transactions: bankId must match JWT bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_056_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    accountId: "1",
    status: "\"pending\"",
    fromDate: "tomorrowStr()",
    toDate: "tomorrowStr()",
  };
}
test.describe("Auth Matrix: GET /api/transactions: bankId must match JWT bankId", () => {
  test("admin must be able to must match JWT `bankId`", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_056_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_056_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to must match JWT `bankId`", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_056_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to must match JWT `bankId`", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_056_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant must match must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_056_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "transactions.list", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in transactions.list", async ({ request }) => {
    // Kills: Remove role check in transactions.list
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_056_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in transactions.list — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access JWT `bankId`", async ({ request }) => {
    // Kills: Allow lower-privileged role to access JWT `bankId`
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_056_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access JWT `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access JWT `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to must match JWT `bankId`", async ({ request }) => {
    // Kills: customer should not be able to must match JWT `bankId`
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_056_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to must match JWT `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to must match JWT `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to must match JWT `bankId`", async ({ request }) => {
    // Kills: advisor should not be able to must match JWT `bankId`
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_056_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to must match JWT `bankId` — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to must match JWT `bankId` — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-057-AUTHMATRIX
// Behavior: Cross-tenant transaction listing returns 403
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_057_AUTHMATRIX() {
  return {
    bankId: TEST_BANK_ID,
    accountId: "1",
    status: "\"pending\"",
    fromDate: "tomorrowStr()",
    toDate: "tomorrowStr()",
  };
}
test.describe("Auth Matrix: Cross-tenant transaction listing returns 403", () => {
  test("admin must be able to returns 403 cross-tenant transaction listing", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_057_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_057_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to returns 403 cross-tenant transaction listing", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_057_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to returns 403 cross-tenant transaction listing", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_057_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant returns 403 must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_057_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "transactions.list", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in transactions.list", async ({ request }) => {
    // Kills: Remove role check in transactions.list
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_057_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in transactions.list — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access cross-tenant transaction listing", async ({ request }) => {
    // Kills: Allow lower-privileged role to access cross-tenant transaction listing
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_057_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access cross-tenant transaction listing — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access cross-tenant transaction listing — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to returns 403 cross-tenant transaction listing", async ({ request }) => {
    // Kills: customer should not be able to returns 403 cross-tenant transaction listing
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_057_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to returns 403 cross-tenant transaction listing — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to returns 403 cross-tenant transaction listing — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to returns 403 cross-tenant transaction listing", async ({ request }) => {
    // Kills: advisor should not be able to returns 403 cross-tenant transaction listing
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "transactions.list", basePayload_PROOF_B_057_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to returns 403 cross-tenant transaction listing — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to returns 403 cross-tenant transaction listing — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-058-AUTHMATRIX
// Behavior: DELETE /api/accounts/:id requires admin authorization
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_058_AUTHMATRIX() {
  return {
    id: "1",
  };
}
test.describe("Auth Matrix: DELETE /api/accounts/:id requires admin authorization", () => {
  test("admin must be able to requires admin authorization", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.delete", basePayload_PROOF_B_058_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.delete", basePayload_PROOF_B_058_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.delete", basePayload_PROOF_B_058_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.delete", basePayload_PROOF_B_058_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant requires must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_058_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.delete", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.delete", async ({ request }) => {
    // Kills: Remove role check in accounts.delete
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.delete", basePayload_PROOF_B_058_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.delete — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access admin authorization", async ({ request }) => {
    // Kills: Allow lower-privileged role to access admin authorization
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.delete", basePayload_PROOF_B_058_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to requires admin authorization", async ({ request }) => {
    // Kills: customer should not be able to requires admin authorization
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.delete", basePayload_PROOF_B_058_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to requires admin authorization", async ({ request }) => {
    // Kills: advisor should not be able to requires admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.delete", basePayload_PROOF_B_058_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-063-AUTHMATRIX
// Behavior: POST /api/accounts/:id/freeze requires admin authorization
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_063_AUTHMATRIX() {
  return {
    id: "1",
    reason: "\"test-reason\"",
  };
}
test.describe("Auth Matrix: POST /api/accounts/:id/freeze requires admin authorization", () => {
  test("admin must be able to requires admin authorization", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.freeze", basePayload_PROOF_B_063_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.freeze", basePayload_PROOF_B_063_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.freeze", basePayload_PROOF_B_063_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.freeze", basePayload_PROOF_B_063_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant requires must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_063_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.freeze", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.freeze", async ({ request }) => {
    // Kills: Remove role check in accounts.freeze
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.freeze", basePayload_PROOF_B_063_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.freeze — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access admin authorization", async ({ request }) => {
    // Kills: Allow lower-privileged role to access admin authorization
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.freeze", basePayload_PROOF_B_063_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to requires admin authorization", async ({ request }) => {
    // Kills: customer should not be able to requires admin authorization
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.freeze", basePayload_PROOF_B_063_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to requires admin authorization", async ({ request }) => {
    // Kills: advisor should not be able to requires admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.freeze", basePayload_PROOF_B_063_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-069-AUTHMATRIX
// Behavior: POST /api/accounts/:id/unfreeze requires admin authorization
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_069_AUTHMATRIX() {
  return {
    id: "1",
  };
}
test.describe("Auth Matrix: POST /api/accounts/:id/unfreeze requires admin authorization", () => {
  test("admin must be able to requires admin authorization", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.unfreeze", basePayload_PROOF_B_069_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "accounts.unfreeze", basePayload_PROOF_B_069_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.unfreeze", basePayload_PROOF_B_069_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.unfreeze", basePayload_PROOF_B_069_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant requires must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_069_AUTHMATRIX(),
      bankId: TEST_BANK_ID + 99999, // Bug 3 Fix: use numeric offset from real tenantConst
    };
    const response = await trpcQuery(request, "accounts.unfreeze", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in accounts.unfreeze", async ({ request }) => {
    // Kills: Remove role check in accounts.unfreeze
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.unfreeze", basePayload_PROOF_B_069_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in accounts.unfreeze — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access admin authorization", async ({ request }) => {
    // Kills: Allow lower-privileged role to access admin authorization
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "accounts.unfreeze", basePayload_PROOF_B_069_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to requires admin authorization", async ({ request }) => {
    // Kills: customer should not be able to requires admin authorization
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "accounts.unfreeze", basePayload_PROOF_B_069_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to requires admin authorization", async ({ request }) => {
    // Kills: advisor should not be able to requires admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "accounts.unfreeze", basePayload_PROOF_B_069_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});