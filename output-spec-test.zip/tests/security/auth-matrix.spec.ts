import { expect, test } from "@playwright/test";
import { BASE_URL, trpcQuery } from "../../helpers/api";
import { getAdminCookie, getAdvisorCookie, getCustomerCookie } from "../../helpers/auth";
import { TEST_BANK_ID } from "../../helpers/factories";

let adminCookie: string;

test.beforeAll(async ({ request }) => {
  adminCookie = await getAdminCookie(request);
});

// Proof: PROOF-B-002-AUTHMATRIX
// Behavior: Each bank (tenant) is isolated by bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_002_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: Each bank (tenant) is isolated by bankId", () => {
  test("admin must be able to is isolated by bankId", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_002_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_002_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to is isolated by bankId", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_002_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to is isolated by bankId", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_002_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant is isolated by must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_002_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_002_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access bankId", async ({ request }) => {
    // Kills: Allow lower-privileged role to access bankId
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_002_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access bankId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access bankId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to is isolated by bankId", async ({ request }) => {
    // Kills: customer should not be able to is isolated by bankId
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_002_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to is isolated by bankId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to is isolated by bankId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to is isolated by bankId", async ({ request }) => {
    // Kills: advisor should not be able to is isolated by bankId
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_002_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to is isolated by bankId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to is isolated by bankId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-014-AUTHMATRIX
// Behavior: Customer role can only access own accounts
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_014_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: Customer role can only access own accounts", () => {
  test("admin must be able to can only access own accounts", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_014_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_014_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to can only access own accounts", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_014_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to can only access own accounts", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_014_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant can only access must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_014_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_014_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access own accounts", async ({ request }) => {
    // Kills: Allow lower-privileged role to access own accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_014_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access own accounts — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access own accounts — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to can only access own accounts", async ({ request }) => {
    // Kills: customer should not be able to can only access own accounts
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_014_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to can only access own accounts — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to can only access own accounts — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to can only access own accounts", async ({ request }) => {
    // Kills: advisor should not be able to can only access own accounts
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_014_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to can only access own accounts — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to can only access own accounts — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-015-AUTHMATRIX
// Behavior: Customer role can only access own transactions
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_015_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: Customer role can only access own transactions", () => {
  test("admin must be able to can only access own transactions", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_015_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_015_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to can only access own transactions", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_015_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to can only access own transactions", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_015_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant can only access must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_015_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_015_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access own transactions", async ({ request }) => {
    // Kills: Allow lower-privileged role to access own transactions
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_015_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access own transactions — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access own transactions — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to can only access own transactions", async ({ request }) => {
    // Kills: customer should not be able to can only access own transactions
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_015_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to can only access own transactions — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to can only access own transactions — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to can only access own transactions", async ({ request }) => {
    // Kills: advisor should not be able to can only access own transactions
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_015_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to can only access own transactions — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to can only access own transactions — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-016-AUTHMATRIX
// Behavior: Advisor role can access all accounts within their bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_016_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: Advisor role can access all accounts within their bankId", () => {
  test("admin must be able to can access all accounts within their bankId", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_016_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_016_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to can access all accounts within their bankId", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_016_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to can access all accounts within their bankId", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_016_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant can access must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_016_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_016_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access all accounts within their bankId", async ({ request }) => {
    // Kills: Allow lower-privileged role to access all accounts within their bankId
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_016_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access all accounts within their bankId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access all accounts within their bankId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to can access all accounts within their bankId", async ({ request }) => {
    // Kills: customer should not be able to can access all accounts within their bankId
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_016_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to can access all accounts within their bankId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to can access all accounts within their bankId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to can access all accounts within their bankId", async ({ request }) => {
    // Kills: advisor should not be able to can access all accounts within their bankId
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_016_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to can access all accounts within their bankId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to can access all accounts within their bankId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-017-AUTHMATRIX
// Behavior: Admin role can access everything within their bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_017_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: Admin role can access everything within their bankId", () => {
  test("admin must be able to can access everything within their bankId", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_017_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_017_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to can access everything within their bankId", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_017_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to can access everything within their bankId", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_017_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant can access must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_017_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_017_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access everything within their bankId", async ({ request }) => {
    // Kills: Allow lower-privileged role to access everything within their bankId
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_017_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access everything within their bankId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access everything within their bankId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to can access everything within their bankId", async ({ request }) => {
    // Kills: customer should not be able to can access everything within their bankId
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_017_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to can access everything within their bankId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to can access everything within their bankId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to can access everything within their bankId", async ({ request }) => {
    // Kills: advisor should not be able to can access everything within their bankId
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_017_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to can access everything within their bankId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to can access everything within their bankId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-018-AUTHMATRIX
// Behavior: Admin role cannot access other banks
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_018_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: Admin role cannot access other banks", () => {
  test("admin must be able to cannot access other banks", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_018_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_018_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to cannot access other banks", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_018_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to cannot access other banks", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_018_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant cannot access must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_018_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_018_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access other banks", async ({ request }) => {
    // Kills: Allow lower-privileged role to access other banks
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_018_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access other banks — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access other banks — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to cannot access other banks", async ({ request }) => {
    // Kills: customer should not be able to cannot access other banks
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_018_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to cannot access other banks — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to cannot access other banks — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to cannot access other banks", async ({ request }) => {
    // Kills: advisor should not be able to cannot access other banks
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_018_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to cannot access other banks — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to cannot access other banks — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-019-AUTHMATRIX
// Behavior: POST /api/accounts requires advisor or admin authorization
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_019_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    accountType: "\"checking\"",
    initialDeposit: "1",
  };
}
test.describe("Auth Matrix: POST /api/accounts requires advisor or admin authorization", () => {
  test("admin must be able to requires advisor or admin authorization", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_019_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_019_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to requires advisor or admin authorization", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_019_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to requires advisor or admin authorization", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_019_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant requires must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_019_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "POST /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in POST /api/accounts", async ({ request }) => {
    // Kills: Remove role check in POST /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_019_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in POST /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access advisor or admin authorization", async ({ request }) => {
    // Kills: Allow lower-privileged role to access advisor or admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_019_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access advisor or admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access advisor or admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to requires advisor or admin authorization", async ({ request }) => {
    // Kills: customer should not be able to requires advisor or admin authorization
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_019_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to requires advisor or admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to requires advisor or admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to requires advisor or admin authorization", async ({ request }) => {
    // Kills: advisor should not be able to requires advisor or admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_019_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to requires advisor or admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to requires advisor or admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-020-AUTHMATRIX
// Behavior: bankId in body must match JWT bankId for account creation
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_020_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    accountType: "\"checking\"",
    initialDeposit: "1",
  };
}
test.describe("Auth Matrix: bankId in body must match JWT bankId for account creation", () => {
  test("admin must be able to validates bankId match", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_020_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_020_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to validates bankId match", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_020_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to validates bankId match", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_020_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant validates must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_020_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "POST /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in POST /api/accounts", async ({ request }) => {
    // Kills: Remove role check in POST /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_020_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in POST /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access bankId match", async ({ request }) => {
    // Kills: Allow lower-privileged role to access bankId match
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_020_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to validates bankId match", async ({ request }) => {
    // Kills: customer should not be able to validates bankId match
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_020_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to validates bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to validates bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to validates bankId match", async ({ request }) => {
    // Kills: advisor should not be able to validates bankId match
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_020_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to validates bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to validates bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-021-AUTHMATRIX
// Behavior: Cross-tenant account creation returns 403
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_021_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    accountType: "\"checking\"",
    initialDeposit: "1",
  };
}
test.describe("Auth Matrix: Cross-tenant account creation returns 403", () => {
  test("admin must be able to returns 403 cross-tenant account creation", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_021_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_021_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to returns 403 cross-tenant account creation", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_021_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to returns 403 cross-tenant account creation", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_021_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant returns 403 must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_021_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "POST /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in POST /api/accounts", async ({ request }) => {
    // Kills: Remove role check in POST /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_021_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in POST /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access cross-tenant account creation", async ({ request }) => {
    // Kills: Allow lower-privileged role to access cross-tenant account creation
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_021_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access cross-tenant account creation — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access cross-tenant account creation — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to returns 403 cross-tenant account creation", async ({ request }) => {
    // Kills: customer should not be able to returns 403 cross-tenant account creation
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_021_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to returns 403 cross-tenant account creation — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to returns 403 cross-tenant account creation — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to returns 403 cross-tenant account creation", async ({ request }) => {
    // Kills: advisor should not be able to returns 403 cross-tenant account creation
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_021_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to returns 403 cross-tenant account creation — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to returns 403 cross-tenant account creation — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-025-AUTHMATRIX
// Behavior: Customer must belong to same bankId for account creation
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_025_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    accountType: "\"checking\"",
    initialDeposit: "1",
  };
}
test.describe("Auth Matrix: Customer must belong to same bankId for account creation", () => {
  test("admin must be able to validates customer bankId match", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_025_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_025_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to validates customer bankId match", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_025_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to validates customer bankId match", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_025_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant validates must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_025_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "POST /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in POST /api/accounts", async ({ request }) => {
    // Kills: Remove role check in POST /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_025_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in POST /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access customer bankId match", async ({ request }) => {
    // Kills: Allow lower-privileged role to access customer bankId match
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_025_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access customer bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access customer bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to validates customer bankId match", async ({ request }) => {
    // Kills: customer should not be able to validates customer bankId match
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_025_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to validates customer bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to validates customer bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to validates customer bankId match", async ({ request }) => {
    // Kills: advisor should not be able to validates customer bankId match
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts", basePayload_PROOF_B_025_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to validates customer bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to validates customer bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-029-AUTHMATRIX
// Behavior: Customer role sees only own accounts when listing
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_029_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: Customer role sees only own accounts when listing", () => {
  test("admin must be able to filters accounts by customerId", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_029_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_029_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to filters accounts by customerId", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_029_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to filters accounts by customerId", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_029_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant filters must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_029_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_029_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access accounts by customerId", async ({ request }) => {
    // Kills: Allow lower-privileged role to access accounts by customerId
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_029_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access accounts by customerId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access accounts by customerId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to filters accounts by customerId", async ({ request }) => {
    // Kills: customer should not be able to filters accounts by customerId
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_029_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to filters accounts by customerId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to filters accounts by customerId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to filters accounts by customerId", async ({ request }) => {
    // Kills: advisor should not be able to filters accounts by customerId
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_029_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to filters accounts by customerId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to filters accounts by customerId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-030-AUTHMATRIX
// Behavior: Advisor/admin can filter accounts by customerId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_030_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: Advisor/admin can filter accounts by customerId", () => {
  test("admin must be able to allows filtering by customerId", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_030_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_030_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to allows filtering by customerId", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_030_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to allows filtering by customerId", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_030_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant allows filtering by must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_030_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_030_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access customerId", async ({ request }) => {
    // Kills: Allow lower-privileged role to access customerId
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_030_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access customerId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access customerId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to allows filtering by customerId", async ({ request }) => {
    // Kills: customer should not be able to allows filtering by customerId
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_030_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to allows filtering by customerId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to allows filtering by customerId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to allows filtering by customerId", async ({ request }) => {
    // Kills: advisor should not be able to allows filtering by customerId
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_030_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to allows filtering by customerId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to allows filtering by customerId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-031-AUTHMATRIX
// Behavior: Advisor/admin can see all accounts within their bank
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_031_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: Advisor/admin can see all accounts within their bank", () => {
  test("admin must be able to displays all accounts within bank", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_031_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_031_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to displays all accounts within bank", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_031_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to displays all accounts within bank", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_031_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant displays must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_031_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_031_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access all accounts within bank", async ({ request }) => {
    // Kills: Allow lower-privileged role to access all accounts within bank
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_031_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access all accounts within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access all accounts within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to displays all accounts within bank", async ({ request }) => {
    // Kills: customer should not be able to displays all accounts within bank
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_031_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to displays all accounts within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to displays all accounts within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to displays all accounts within bank", async ({ request }) => {
    // Kills: advisor should not be able to displays all accounts within bank
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_031_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to displays all accounts within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to displays all accounts within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-032-AUTHMATRIX
// Behavior: GET /api/accounts bankId must match JWT bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_032_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: GET /api/accounts bankId must match JWT bankId", () => {
  test("admin must be able to validates bankId match", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_032_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_032_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to validates bankId match", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_032_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to validates bankId match", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_032_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant validates must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_032_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_032_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access bankId match", async ({ request }) => {
    // Kills: Allow lower-privileged role to access bankId match
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_032_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to validates bankId match", async ({ request }) => {
    // Kills: customer should not be able to validates bankId match
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_032_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to validates bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to validates bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to validates bankId match", async ({ request }) => {
    // Kills: advisor should not be able to validates bankId match
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_032_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to validates bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to validates bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-033-AUTHMATRIX
// Behavior: Cross-tenant account listing returns 403 with empty data
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_033_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    customerId: "1",
    status: "\"active\"",
  };
}
test.describe("Auth Matrix: Cross-tenant account listing returns 403 with empty data", () => {
  test("admin must be able to returns 403 with empty data cross-tenant account listing", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_033_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_033_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to returns 403 with empty data cross-tenant account listing", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_033_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to returns 403 with empty data cross-tenant account listing", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_033_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant returns 403 with empty data must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_033_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_033_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access cross-tenant account listing", async ({ request }) => {
    // Kills: Allow lower-privileged role to access cross-tenant account listing
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_033_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access cross-tenant account listing — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access cross-tenant account listing — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to returns 403 with empty data cross-tenant account listing", async ({ request }) => {
    // Kills: customer should not be able to returns 403 with empty data cross-tenant account listing
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_033_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to returns 403 with empty data cross-tenant account listing — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to returns 403 with empty data cross-tenant account listing — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to returns 403 with empty data cross-tenant account listing", async ({ request }) => {
    // Kills: advisor should not be able to returns 403 with empty data cross-tenant account listing
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts", basePayload_PROOF_B_033_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to returns 403 with empty data cross-tenant account listing — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to returns 403 with empty data cross-tenant account listing — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-034-AUTHMATRIX
// Behavior: Customer can only access own account via GET /api/accounts/:id
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_034_AUTHMATRIX() {
  return {
    id: "1",
  };
}
test.describe("Auth Matrix: Customer can only access own account via GET /api/accounts/:id", () => {
  test("admin must be able to restricts access to own account", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_034_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_034_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to restricts access to own account", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_034_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to restricts access to own account", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_034_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant restricts access to must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_034_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts/:id", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts/:id", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts/:id
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_034_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts/:id — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access own account", async ({ request }) => {
    // Kills: Allow lower-privileged role to access own account
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_034_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access own account — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access own account — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to restricts access to own account", async ({ request }) => {
    // Kills: customer should not be able to restricts access to own account
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_034_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to restricts access to own account — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to restricts access to own account — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to restricts access to own account", async ({ request }) => {
    // Kills: advisor should not be able to restricts access to own account
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_034_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to restricts access to own account — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to restricts access to own account — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-035-AUTHMATRIX
// Behavior: Advisor/admin can access any account within their bank via GET /api/accounts/:id
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_035_AUTHMATRIX() {
  return {
    id: "1",
  };
}
test.describe("Auth Matrix: Advisor/admin can access any account within their bank via GET /api/accounts/:id", () => {
  test("admin must be able to allows access to any account within bank", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_035_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_035_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to allows access to any account within bank", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_035_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to allows access to any account within bank", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_035_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant allows access to must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_035_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts/:id", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts/:id", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts/:id
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_035_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts/:id — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access any account within bank", async ({ request }) => {
    // Kills: Allow lower-privileged role to access any account within bank
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_035_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access any account within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access any account within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to allows access to any account within bank", async ({ request }) => {
    // Kills: customer should not be able to allows access to any account within bank
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_035_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to allows access to any account within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to allows access to any account within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to allows access to any account within bank", async ({ request }) => {
    // Kills: advisor should not be able to allows access to any account within bank
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_035_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to allows access to any account within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to allows access to any account within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-037-AUTHMATRIX
// Behavior: GET /api/accounts/:id returns 403 if account belongs to different bank
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_037_AUTHMATRIX() {
  return {
    id: "1",
  };
}
test.describe("Auth Matrix: GET /api/accounts/:id returns 403 if account belongs to different bank", () => {
  test("admin must be able to returns 403 account from different bank", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_037_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_037_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to returns 403 account from different bank", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_037_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to returns 403 account from different bank", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_037_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant returns 403 must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_037_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts/:id", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts/:id", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts/:id
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_037_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts/:id — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access account from different bank", async ({ request }) => {
    // Kills: Allow lower-privileged role to access account from different bank
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_037_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access account from different bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access account from different bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to returns 403 account from different bank", async ({ request }) => {
    // Kills: customer should not be able to returns 403 account from different bank
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_037_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to returns 403 account from different bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to returns 403 account from different bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to returns 403 account from different bank", async ({ request }) => {
    // Kills: advisor should not be able to returns 403 account from different bank
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_037_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to returns 403 account from different bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to returns 403 account from different bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-038-AUTHMATRIX
// Behavior: GET /api/accounts/:id returns 403 if customer role and account.customerId !== jwt.userId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_038_AUTHMATRIX() {
  return {
    id: "1",
  };
}
test.describe("Auth Matrix: GET /api/accounts/:id returns 403 if customer role and account.customerId !== jwt.userId", () => {
  test("admin must be able to returns 403 account not owned by customer", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_038_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_038_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to returns 403 account not owned by customer", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_038_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to returns 403 account not owned by customer", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_038_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant returns 403 must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_038_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/accounts/:id", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/accounts/:id", async ({ request }) => {
    // Kills: Remove role check in GET /api/accounts/:id
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_038_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/accounts/:id — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access account not owned by customer", async ({ request }) => {
    // Kills: Allow lower-privileged role to access account not owned by customer
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_038_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access account not owned by customer — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access account not owned by customer — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to returns 403 account not owned by customer", async ({ request }) => {
    // Kills: customer should not be able to returns 403 account not owned by customer
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_038_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to returns 403 account not owned by customer — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to returns 403 account not owned by customer — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to returns 403 account not owned by customer", async ({ request }) => {
    // Kills: advisor should not be able to returns 403 account not owned by customer
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/accounts/:id", basePayload_PROOF_B_038_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to returns 403 account not owned by customer — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to returns 403 account not owned by customer — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-039-AUTHMATRIX
// Behavior: POST /api/transactions requires advisor or admin authorization
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_039_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    fromAccountId: "1",
    toAccountId: "1",
    amount: "1",
    description: "\"Test description\"",
    idempotencyKey: "TEST_BANK_ID",
  };
}
test.describe("Auth Matrix: POST /api/transactions requires advisor or admin authorization", () => {
  test("admin must be able to requires advisor or admin authorization", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_039_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_039_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to requires advisor or admin authorization", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_039_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to requires advisor or admin authorization", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_039_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant requires must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_039_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "POST /api/transactions", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in POST /api/transactions", async ({ request }) => {
    // Kills: Remove role check in POST /api/transactions
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_039_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in POST /api/transactions — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access advisor or admin authorization", async ({ request }) => {
    // Kills: Allow lower-privileged role to access advisor or admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_039_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access advisor or admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access advisor or admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to requires advisor or admin authorization", async ({ request }) => {
    // Kills: customer should not be able to requires advisor or admin authorization
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_039_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to requires advisor or admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to requires advisor or admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to requires advisor or admin authorization", async ({ request }) => {
    // Kills: advisor should not be able to requires advisor or admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_039_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to requires advisor or admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to requires advisor or admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-040-AUTHMATRIX
// Behavior: bankId for transaction must match JWT bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_040_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    fromAccountId: "1",
    toAccountId: "1",
    amount: "1",
    description: "\"Test description\"",
    idempotencyKey: "TEST_BANK_ID",
  };
}
test.describe("Auth Matrix: bankId for transaction must match JWT bankId", () => {
  test("admin must be able to validates bankId match", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_040_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_040_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to validates bankId match", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_040_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to validates bankId match", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_040_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant validates must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_040_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "POST /api/transactions", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in POST /api/transactions", async ({ request }) => {
    // Kills: Remove role check in POST /api/transactions
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_040_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in POST /api/transactions — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access bankId match", async ({ request }) => {
    // Kills: Allow lower-privileged role to access bankId match
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_040_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to validates bankId match", async ({ request }) => {
    // Kills: customer should not be able to validates bankId match
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_040_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to validates bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to validates bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to validates bankId match", async ({ request }) => {
    // Kills: advisor should not be able to validates bankId match
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_040_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to validates bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to validates bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-041-AUTHMATRIX
// Behavior: Cross-tenant transaction creation returns 403
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_041_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    fromAccountId: "1",
    toAccountId: "1",
    amount: "1",
    description: "\"Test description\"",
    idempotencyKey: "TEST_BANK_ID",
  };
}
test.describe("Auth Matrix: Cross-tenant transaction creation returns 403", () => {
  test("admin must be able to returns 403 cross-tenant transaction creation", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_041_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_041_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to returns 403 cross-tenant transaction creation", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_041_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to returns 403 cross-tenant transaction creation", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_041_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant returns 403 must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_041_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "POST /api/transactions", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in POST /api/transactions", async ({ request }) => {
    // Kills: Remove role check in POST /api/transactions
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_041_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in POST /api/transactions — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access cross-tenant transaction creation", async ({ request }) => {
    // Kills: Allow lower-privileged role to access cross-tenant transaction creation
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_041_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access cross-tenant transaction creation — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access cross-tenant transaction creation — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to returns 403 cross-tenant transaction creation", async ({ request }) => {
    // Kills: customer should not be able to returns 403 cross-tenant transaction creation
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_041_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to returns 403 cross-tenant transaction creation — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to returns 403 cross-tenant transaction creation — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to returns 403 cross-tenant transaction creation", async ({ request }) => {
    // Kills: advisor should not be able to returns 403 cross-tenant transaction creation
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_041_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to returns 403 cross-tenant transaction creation — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to returns 403 cross-tenant transaction creation — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-042-AUTHMATRIX
// Behavior: fromAccountId and toAccountId must belong to same bankId for transaction
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_042_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    fromAccountId: "1",
    toAccountId: "1",
    amount: "1",
    description: "\"Test description\"",
    idempotencyKey: "TEST_BANK_ID",
  };
}
test.describe("Auth Matrix: fromAccountId and toAccountId must belong to same bankId for transaction", () => {
  test("admin must be able to validates account bankId match", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_042_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_042_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to validates account bankId match", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_042_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to validates account bankId match", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_042_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant validates must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_042_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "POST /api/transactions", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in POST /api/transactions", async ({ request }) => {
    // Kills: Remove role check in POST /api/transactions
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_042_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in POST /api/transactions — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access account bankId match", async ({ request }) => {
    // Kills: Allow lower-privileged role to access account bankId match
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_042_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access account bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access account bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to validates account bankId match", async ({ request }) => {
    // Kills: customer should not be able to validates account bankId match
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_042_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to validates account bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to validates account bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to validates account bankId match", async ({ request }) => {
    // Kills: advisor should not be able to validates account bankId match
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_042_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to validates account bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to validates account bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-043-AUTHMATRIX
// Behavior: POST /api/transactions returns 403 if fromAccountId and toAccountId do not belong to same bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_043_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    fromAccountId: "1",
    toAccountId: "1",
    amount: "1",
    description: "\"Test description\"",
    idempotencyKey: "TEST_BANK_ID",
  };
}
test.describe("Auth Matrix: POST /api/transactions returns 403 if fromAccountId and toAccountId do not belong to same bankId", () => {
  test("admin must be able to returns 403 cross-bank account transaction", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_043_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_043_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to returns 403 cross-bank account transaction", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_043_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to returns 403 cross-bank account transaction", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_043_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant returns 403 must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_043_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "POST /api/transactions", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in POST /api/transactions", async ({ request }) => {
    // Kills: Remove role check in POST /api/transactions
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_043_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in POST /api/transactions — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access cross-bank account transaction", async ({ request }) => {
    // Kills: Allow lower-privileged role to access cross-bank account transaction
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_043_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access cross-bank account transaction — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access cross-bank account transaction — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to returns 403 cross-bank account transaction", async ({ request }) => {
    // Kills: customer should not be able to returns 403 cross-bank account transaction
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_043_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to returns 403 cross-bank account transaction — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to returns 403 cross-bank account transaction — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to returns 403 cross-bank account transaction", async ({ request }) => {
    // Kills: advisor should not be able to returns 403 cross-bank account transaction
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/transactions", basePayload_PROOF_B_043_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to returns 403 cross-bank account transaction — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to returns 403 cross-bank account transaction — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-053-AUTHMATRIX
// Behavior: PATCH /api/transactions/:id/status requires admin authorization
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_053_AUTHMATRIX() {
  return {
    id: "1",
    status: "\"processing\"",
  };
}
test.describe("Auth Matrix: PATCH /api/transactions/:id/status requires admin authorization", () => {
  test("admin must be able to requires admin authorization", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "PATCH /api/transactions/:id/status", basePayload_PROOF_B_053_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "PATCH /api/transactions/:id/status", basePayload_PROOF_B_053_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "PATCH /api/transactions/:id/status", basePayload_PROOF_B_053_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "PATCH /api/transactions/:id/status", basePayload_PROOF_B_053_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant requires must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_053_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "PATCH /api/transactions/:id/status", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in PATCH /api/transactions/:id/status", async ({ request }) => {
    // Kills: Remove role check in PATCH /api/transactions/:id/status
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "PATCH /api/transactions/:id/status", basePayload_PROOF_B_053_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in PATCH /api/transactions/:id/status — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access admin authorization", async ({ request }) => {
    // Kills: Allow lower-privileged role to access admin authorization
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "PATCH /api/transactions/:id/status", basePayload_PROOF_B_053_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to requires admin authorization", async ({ request }) => {
    // Kills: customer should not be able to requires admin authorization
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "PATCH /api/transactions/:id/status", basePayload_PROOF_B_053_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to requires admin authorization", async ({ request }) => {
    // Kills: advisor should not be able to requires admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "PATCH /api/transactions/:id/status", basePayload_PROOF_B_053_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-066-AUTHMATRIX
// Behavior: Customer role sees only own transactions when listing
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_066_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    accountId: "1",
    status: "\"pending\"",
    fromDate: "tomorrowStr()",
    toDate: "tomorrowStr()",
  };
}
test.describe("Auth Matrix: Customer role sees only own transactions when listing", () => {
  test("admin must be able to filters transactions by customerId", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_066_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_066_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to filters transactions by customerId", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_066_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to filters transactions by customerId", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_066_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant filters must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_066_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/transactions", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/transactions", async ({ request }) => {
    // Kills: Remove role check in GET /api/transactions
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_066_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/transactions — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access transactions by customerId", async ({ request }) => {
    // Kills: Allow lower-privileged role to access transactions by customerId
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_066_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access transactions by customerId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access transactions by customerId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to filters transactions by customerId", async ({ request }) => {
    // Kills: customer should not be able to filters transactions by customerId
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_066_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to filters transactions by customerId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to filters transactions by customerId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to filters transactions by customerId", async ({ request }) => {
    // Kills: advisor should not be able to filters transactions by customerId
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_066_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to filters transactions by customerId — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to filters transactions by customerId — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-067-AUTHMATRIX
// Behavior: Advisor/admin sees all transactions within bank when listing
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_067_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    accountId: "1",
    status: "\"pending\"",
    fromDate: "tomorrowStr()",
    toDate: "tomorrowStr()",
  };
}
test.describe("Auth Matrix: Advisor/admin sees all transactions within bank when listing", () => {
  test("admin must be able to displays all transactions within bank", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_067_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_067_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to displays all transactions within bank", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_067_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to displays all transactions within bank", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_067_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant displays must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_067_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/transactions", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/transactions", async ({ request }) => {
    // Kills: Remove role check in GET /api/transactions
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_067_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/transactions — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access all transactions within bank", async ({ request }) => {
    // Kills: Allow lower-privileged role to access all transactions within bank
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_067_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access all transactions within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access all transactions within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to displays all transactions within bank", async ({ request }) => {
    // Kills: customer should not be able to displays all transactions within bank
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_067_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to displays all transactions within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to displays all transactions within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to displays all transactions within bank", async ({ request }) => {
    // Kills: advisor should not be able to displays all transactions within bank
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_067_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to displays all transactions within bank — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to displays all transactions within bank — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-068-AUTHMATRIX
// Behavior: GET /api/transactions bankId must match JWT bankId
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_068_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    accountId: "1",
    status: "\"pending\"",
    fromDate: "tomorrowStr()",
    toDate: "tomorrowStr()",
  };
}
test.describe("Auth Matrix: GET /api/transactions bankId must match JWT bankId", () => {
  test("admin must be able to validates bankId match", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_068_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_068_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to validates bankId match", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_068_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to validates bankId match", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_068_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant validates must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_068_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/transactions", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/transactions", async ({ request }) => {
    // Kills: Remove role check in GET /api/transactions
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_068_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/transactions — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access bankId match", async ({ request }) => {
    // Kills: Allow lower-privileged role to access bankId match
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_068_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to validates bankId match", async ({ request }) => {
    // Kills: customer should not be able to validates bankId match
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_068_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to validates bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to validates bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to validates bankId match", async ({ request }) => {
    // Kills: advisor should not be able to validates bankId match
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_068_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to validates bankId match — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to validates bankId match — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-069-AUTHMATRIX
// Behavior: Cross-tenant transaction listing returns 403
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_069_AUTHMATRIX() {
  return {
    bankId: "TEST_BANK_ID",
    accountId: "1",
    status: "\"pending\"",
    fromDate: "tomorrowStr()",
    toDate: "tomorrowStr()",
  };
}
test.describe("Auth Matrix: Cross-tenant transaction listing returns 403", () => {
  test("admin must be able to returns 403 cross-tenant transaction listing", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_069_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_069_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to returns 403 cross-tenant transaction listing", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_069_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to returns 403 cross-tenant transaction listing", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_069_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant returns 403 must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_069_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "GET /api/transactions", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in GET /api/transactions", async ({ request }) => {
    // Kills: Remove role check in GET /api/transactions
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_069_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in GET /api/transactions — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access cross-tenant transaction listing", async ({ request }) => {
    // Kills: Allow lower-privileged role to access cross-tenant transaction listing
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_069_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access cross-tenant transaction listing — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access cross-tenant transaction listing — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to returns 403 cross-tenant transaction listing", async ({ request }) => {
    // Kills: customer should not be able to returns 403 cross-tenant transaction listing
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_069_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to returns 403 cross-tenant transaction listing — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to returns 403 cross-tenant transaction listing — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to returns 403 cross-tenant transaction listing", async ({ request }) => {
    // Kills: advisor should not be able to returns 403 cross-tenant transaction listing
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "GET /api/transactions", basePayload_PROOF_B_069_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to returns 403 cross-tenant transaction listing — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to returns 403 cross-tenant transaction listing — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-070-AUTHMATRIX
// Behavior: DELETE /api/accounts/:id requires admin authorization
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_070_AUTHMATRIX() {
  return {
    id: "1",
  };
}
test.describe("Auth Matrix: DELETE /api/accounts/:id requires admin authorization", () => {
  test("admin must be able to requires admin authorization", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "DELETE /api/accounts/:id", basePayload_PROOF_B_070_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "DELETE /api/accounts/:id", basePayload_PROOF_B_070_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "DELETE /api/accounts/:id", basePayload_PROOF_B_070_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "DELETE /api/accounts/:id", basePayload_PROOF_B_070_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant requires must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_070_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "DELETE /api/accounts/:id", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in DELETE /api/accounts/:id", async ({ request }) => {
    // Kills: Remove role check in DELETE /api/accounts/:id
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "DELETE /api/accounts/:id", basePayload_PROOF_B_070_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in DELETE /api/accounts/:id — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access admin authorization", async ({ request }) => {
    // Kills: Allow lower-privileged role to access admin authorization
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "DELETE /api/accounts/:id", basePayload_PROOF_B_070_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to requires admin authorization", async ({ request }) => {
    // Kills: customer should not be able to requires admin authorization
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "DELETE /api/accounts/:id", basePayload_PROOF_B_070_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to requires admin authorization", async ({ request }) => {
    // Kills: advisor should not be able to requires admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "DELETE /api/accounts/:id", basePayload_PROOF_B_070_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-077-AUTHMATRIX
// Behavior: POST /api/accounts/:id/freeze requires admin authorization
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_077_AUTHMATRIX() {
  return {
    id: "1",
    reason: "\"test-reason\"",
  };
}
test.describe("Auth Matrix: POST /api/accounts/:id/freeze requires admin authorization", () => {
  test("admin must be able to requires admin authorization", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts/:id/freeze", basePayload_PROOF_B_077_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "POST /api/accounts/:id/freeze", basePayload_PROOF_B_077_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts/:id/freeze", basePayload_PROOF_B_077_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts/:id/freeze", basePayload_PROOF_B_077_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant requires must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_077_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "POST /api/accounts/:id/freeze", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in POST /api/accounts/:id/freeze", async ({ request }) => {
    // Kills: Remove role check in POST /api/accounts/:id/freeze
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts/:id/freeze", basePayload_PROOF_B_077_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in POST /api/accounts/:id/freeze — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access admin authorization", async ({ request }) => {
    // Kills: Allow lower-privileged role to access admin authorization
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts/:id/freeze", basePayload_PROOF_B_077_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to requires admin authorization", async ({ request }) => {
    // Kills: customer should not be able to requires admin authorization
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts/:id/freeze", basePayload_PROOF_B_077_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to requires admin authorization", async ({ request }) => {
    // Kills: advisor should not be able to requires admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts/:id/freeze", basePayload_PROOF_B_077_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});

// Proof: PROOF-B-083-AUTHMATRIX
// Behavior: POST /api/accounts/:id/unfreeze requires admin authorization
// Risk: critical
// MutationTargets: 4 kills required for 100% mutation score
function basePayload_PROOF_B_083_AUTHMATRIX() {
  return {
    id: "1",
  };
}
test.describe("Auth Matrix: POST /api/accounts/:id/unfreeze requires admin authorization", () => {
  test("admin must be able to requires admin authorization", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts/:id/unfreeze", basePayload_PROOF_B_083_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Verify response has data (not empty)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
  });
  test("unauthenticated request must be rejected", async ({ request }) => {
    const response = await trpcQuery(request, "POST /api/accounts/:id/unfreeze", basePayload_PROOF_B_083_AUTHMATRIX(), "");
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak data to unauthenticated callers
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
    // Verify error code is UNAUTHORIZED
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("customer must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts/:id/unfreeze", basePayload_PROOF_B_083_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });

  test("advisor must NOT be able to requires admin authorization", async ({ request }) => {
    const roleCookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts/:id/unfreeze", basePayload_PROOF_B_083_AUTHMATRIX(), roleCookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Must not leak any data in error response
    const data = response.data?.result?.data;
    expect(data).toBeFalsy();
  });
  test("cross-tenant requires must be rejected", async ({ request }) => {
    const cookie = await getAdminCookie(request);
    const crossTenantPayload = {
      ...basePayload_PROOF_B_083_AUTHMATRIX(),
      bankId: "DIFFERENT_TENANT_ID_THAT_DOES_NOT_BELONG_TO_CALLER",
    };
    const response = await trpcQuery(request, "POST /api/accounts/:id/unfreeze", crossTenantPayload, cookie);
    expect(response.status).toBeOneOf([401, 403, 404]);
    // Must not leak data from other tenant
    const leakedData = response.data?.result?.data;
    expect(leakedData).toBeFalsy();
  });

  test("mutation-kill-1: Remove role check in POST /api/accounts/:id/unfreeze", async ({ request }) => {
    // Kills: Remove role check in POST /api/accounts/:id/unfreeze
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts/:id/unfreeze", basePayload_PROOF_B_083_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([200, 201]);
    // Kills: Remove role check in POST /api/accounts/:id/unfreeze — verify response has expected structure (not empty/null)
    const data = response.data?.result?.data;
    expect(data).not.toBeNull();
    expect(data).not.toBeUndefined();
  });

  test("mutation-kill-2: Allow lower-privileged role to access admin authorization", async ({ request }) => {
    // Kills: Allow lower-privileged role to access admin authorization
    const cookie = await getAdminCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts/:id/unfreeze", basePayload_PROOF_B_083_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: Allow lower-privileged role to access admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: Allow lower-privileged role to access admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-3: customer should not be able to requires admin authorization", async ({ request }) => {
    // Kills: customer should not be able to requires admin authorization
    const cookie = await getCustomerCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts/:id/unfreeze", basePayload_PROOF_B_083_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: customer should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: customer should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });

  test("mutation-kill-4: advisor should not be able to requires admin authorization", async ({ request }) => {
    // Kills: advisor should not be able to requires admin authorization
    const cookie = await getAdvisorCookie(request);
    const response = await trpcQuery(request, "POST /api/accounts/:id/unfreeze", basePayload_PROOF_B_083_AUTHMATRIX(), cookie);
    expect(response.status).toBeOneOf([401, 403]);
    // Kills: advisor should not be able to requires admin authorization — verify no data leaked in error response
    const body = response.data?.result?.data ?? response.data?.result?.error;
    expect(body).toBeFalsy();
    // Kills: advisor should not be able to requires admin authorization — verify error code is present
    const errorCode = response.data?.error?.data?.code ?? response.data?.result?.error?.data?.code;
    expect(["FORBIDDEN", "UNAUTHORIZED"]).toContain(errorCode);
  });
});