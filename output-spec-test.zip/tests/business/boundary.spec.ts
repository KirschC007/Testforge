import { expect, test } from "@playwright/test";
import { trpcMutation } from "../../helpers/api";
import { getCustomerCookie } from "../../helpers/auth";
import { TEST_BANK_ID } from "../../helpers/factories";

let adminCookie: string;

test.beforeAll(async ({ request }) => {
  adminCookie = await getAdminCookie(request);
});

// PROOF-B-026-BOUND — Boundary: POST /api/accounts returns 400 if accountType is not in enum
// Risk: medium
// Boundary Field: initialDeposit (number, min: 0, max: 1000000)

const basePayload_PROOF_B_026_BOUND = (boundaryValue: unknown) => ({
    bankId: TEST_BANK_ID,
    customerId: 1,
    accountType: "checking",
    initialDeposit: boundaryValue,
});

test("PROOF-B-026-BOUNDa — initialDeposit=0 (minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_026_BOUND(0), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in initialDeposit validation (off-by-one)
});

test("PROOF-B-026-BOUNDb — initialDeposit=1000000 (maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_026_BOUND(1000000), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in initialDeposit validation (off-by-one)
});

test("PROOF-B-026-BOUNDc — initialDeposit=-1 (below minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_026_BOUND(-1), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});

test("PROOF-B-026-BOUNDd — initialDeposit=1000001 (above maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_026_BOUND(1000001), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});

test("PROOF-B-026-BOUNDe — initialDeposit=null", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_026_BOUND(null), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});

// PROOF-B-027-BOUND — Boundary: POST /api/accounts returns 400 if initialDeposit < 0
// Risk: medium
// Boundary Field: initialDeposit (number, min: 0, max: 1000000)

const basePayload_PROOF_B_027_BOUND = (boundaryValue: unknown) => ({
    bankId: TEST_BANK_ID,
    customerId: 1,
    accountType: "checking",
    initialDeposit: boundaryValue,
});

test("PROOF-B-027-BOUNDa — initialDeposit=0 (minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_027_BOUND(0), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in initialDeposit validation (off-by-one)
});

test("PROOF-B-027-BOUNDb — initialDeposit=1000000 (maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_027_BOUND(1000000), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in initialDeposit validation (off-by-one)
});

test("PROOF-B-027-BOUNDc — initialDeposit=-1 (below minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_027_BOUND(-1), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});

test("PROOF-B-027-BOUNDd — initialDeposit=1000001 (above maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_027_BOUND(1000001), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});

test("PROOF-B-027-BOUNDe — initialDeposit=null", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_027_BOUND(null), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});

// PROOF-B-028-BOUND — Boundary: POST /api/accounts returns 400 if initialDeposit > 1000000
// Risk: medium
// Boundary Field: initialDeposit (number, min: 0, max: 1000000)

const basePayload_PROOF_B_028_BOUND = (boundaryValue: unknown) => ({
    bankId: TEST_BANK_ID,
    customerId: 1,
    accountType: "checking",
    initialDeposit: boundaryValue,
});

test("PROOF-B-028-BOUNDa — initialDeposit=0 (minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_028_BOUND(0), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in initialDeposit validation (off-by-one)
});

test("PROOF-B-028-BOUNDb — initialDeposit=1000000 (maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_028_BOUND(1000000), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in initialDeposit validation (off-by-one)
});

test("PROOF-B-028-BOUNDc — initialDeposit=-1 (below minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_028_BOUND(-1), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});

test("PROOF-B-028-BOUNDd — initialDeposit=1000001 (above maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_028_BOUND(1000001), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});

test("PROOF-B-028-BOUNDe — initialDeposit=null", async ({ request }) => {
  const { status } = await trpcMutation(request, "POST /api/accounts", basePayload_PROOF_B_028_BOUND(null), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});