import { expect, test } from "@playwright/test";
import { trpcMutation } from "../../helpers/api";
import { getCustomerCookie } from "../../helpers/auth";
import { TEST_BANK_ID } from "../../helpers/factories";

let adminCookie: string;

test.beforeAll(async ({ request }) => {
  adminCookie = await getAdminCookie(request);
});

// PROOF-B-025-BOUND — Boundary: POST /api/accounts returns 400 if accountType is not in enum
// Risk: medium
// Boundary Field: initialDeposit (number, min: 0, max: 1000000)

const basePayload_PROOF_B_025_BOUND = (boundaryValue: unknown) => ({
    bankId: TEST_BANK_ID,
    customerId: 1,
    accountType: "checking",
    initialDeposit: boundaryValue,
});

test("PROOF-B-025-BOUNDa — initialDeposit=0 (minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.create", basePayload_PROOF_B_025_BOUND(0), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in initialDeposit validation (off-by-one)
});

test("PROOF-B-025-BOUNDb — initialDeposit=1000000 (maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.create", basePayload_PROOF_B_025_BOUND(1000000), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in initialDeposit validation (off-by-one)
});

test("PROOF-B-025-BOUNDc — initialDeposit=-1 (below minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.create", basePayload_PROOF_B_025_BOUND(-1), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});

test("PROOF-B-025-BOUNDd — initialDeposit=1000001 (above maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.create", basePayload_PROOF_B_025_BOUND(1000001), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});

test("PROOF-B-025-BOUNDe — initialDeposit=null", async ({ request }) => {
  const { status } = await trpcMutation(request, "accounts.create", basePayload_PROOF_B_025_BOUND(null), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove initialDeposit boundary validation
});

// PROOF-B-041-BOUND — Boundary: Transaction creation returns 422 INSUFFICIENT_BALANCE if fromAccountId has insufficient balance
// Risk: high
// Boundary Field: amount (number, min: 1, max: 50000000)

const basePayload_PROOF_B_041_BOUND = (boundaryValue: unknown) => ({
    bankId: TEST_BANK_ID,
    fromAccountId: 1,
    toAccountId: 1,
    idempotencyKey: TEST_BANK_ID,
    amount: boundaryValue,
});

test("PROOF-B-041-BOUNDa — amount=1.00 (minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "transactions.create", basePayload_PROOF_B_041_BOUND(1.00), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in amount validation (off-by-one)
});

test("PROOF-B-041-BOUNDb — amount=50000000.00 (maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "transactions.create", basePayload_PROOF_B_041_BOUND(50000000.00), adminCookie);
  expect(status).toBe(200);
  // Kills: Change >= to > in amount validation (off-by-one)
});

test("PROOF-B-041-BOUNDc — amount=0.99 (below minimum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "transactions.create", basePayload_PROOF_B_041_BOUND(0.99), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove amount boundary validation
});

test("PROOF-B-041-BOUNDd — amount=50000000.01 (above maximum)", async ({ request }) => {
  const { status } = await trpcMutation(request, "transactions.create", basePayload_PROOF_B_041_BOUND(50000000.01), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove amount boundary validation
});

test("PROOF-B-041-BOUNDe — amount=null", async ({ request }) => {
  const { status } = await trpcMutation(request, "transactions.create", basePayload_PROOF_B_041_BOUND(null), adminCookie);
  expect([400, 422]).toContain(status);
  // Kills: Remove amount boundary validation
});