import { expect, test } from "@playwright/test";
import { trpcMutation, trpcQuery } from "../../helpers/api";
import { getAdminCookie } from "../../helpers/auth";
import { TEST_BANK_ID, createTestResource } from "../../helpers/factories";

let adminCookie: string;

test.beforeAll(async ({ request }) => {
  adminCookie = await getAdminCookie(request);
});

// PROOF-B-019-BL — Business Logic: POST /api/accounts requires advisor or admin authorization
// Risk: critical | Endpoint: POST /api/accounts
// Spec: Endpoints
// Behavior: POST /api/accounts requires advisor or admin authorization

test("PROOF-B-019-BLa — POST /api/accounts requires advisor or admin authorization", async ({ request }) => {
  // Precondition: valid authenticated user
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined();

  // Act
  const { data, status } = await trpcMutation(request, "POST /api/accounts", {
    bankId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in POST /api/accounts
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  // Kills: Remove success path in POST /api/accounts
});
test("PROOF-B-019-BLb — POST /api/accounts requires advisor or admin authorization requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  const { status } = await trpcMutation(request, "POST /api/accounts", {
    bankId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from POST /api/accounts
});
test("PROOF-B-019-BLc — POST /api/accounts requires advisor or admin authorization persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined(); // Kills: Don't return id from POST /api/accounts
  const { data: fetched, status } = await trpcQuery(request, "GET /api/accounts",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove GET /api/accounts endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === bankId)).toBe(true); // Kills: Don't persist to DB
});

// PROOF-B-022-BL — Business Logic: initialDeposit is added to balance atomically
// Risk: high | Endpoint: POST /api/accounts
// Spec: Endpoints
// Behavior: initialDeposit is added to balance atomically

test("PROOF-B-022-BLa — balance deducted after initialDeposit is added to balance atomically", async ({ request }) => {
  // Arrange: Create fromAccount and toAccount with known balances
  const fromAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const toAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(fromAccount?.id).toBeDefined();
  expect(toAccount?.id).toBeDefined();

  // Read balance BEFORE transaction
  const { data: fromBefore } = await trpcQuery(request, "GET /api/accounts",
    { bankId: TEST_BANK_ID }, adminCookie);
  const balanceBefore = (Array.isArray(fromBefore) ? fromBefore : [fromBefore])
    .find((a: unknown) => (a as Record<string, unknown>).id === fromAccount.id)
    ?.balance as number ?? 0;
  expect(typeof balanceBefore).toBe("number");
  // Kills: Cannot read balance before transaction

  // Act: Execute the transaction
  const AMOUNT = 1;
  const { status, data } = await trpcMutation(request, "POST /api/accounts", {
    bankId: TEST_BANK_ID,
    customerId: 1,
    accountType: "checking",
    initialDeposit: 1,
  }, adminCookie);
  expect(status).toBe(200);
  // Kills: Remove success path in POST /api/accounts

  // Read balance AFTER transaction
  const { data: fromAfter } = await trpcQuery(request, "GET /api/accounts",
    { bankId: TEST_BANK_ID }, adminCookie);
  const balanceAfter = (Array.isArray(fromAfter) ? fromAfter : [fromAfter])
    .find((a: unknown) => (a as Record<string, unknown>).id === fromAccount.id)
    ?.balance as number;

  expect(balanceAfter).toBe(balanceBefore - AMOUNT);
  // Kills: Not deducting amount from fromAccount.balance
  expect(balanceAfter).toBeGreaterThanOrEqual(0);
  // Kills: Allow negative balance (insufficient funds check missing)
  // Kills: Remove success path in POST /api/accounts
  // Kills: Not updating Account balance updated atomically after is added to in POST /api/accounts
});
test("PROOF-B-022-BLb — initialDeposit is added to balance atomically requires auth", async ({ request }) => {
  const fromAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const toAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const { status } = await trpcMutation(request, "POST /api/accounts", {
    bankId: TEST_BANK_ID,
    fromAccountId: fromAccount.id as number,
    toAccountId: toAccount.id as number,
    amount: 1,
  }, ""); // No cookie
  expect([401, 403]).toContain(status);
  // Kills: Remove auth middleware from POST /api/accounts
});

// PROOF-B-030-BL — Business Logic: Advisor/admin can filter accounts by customerId
// Risk: critical | Endpoint: GET /api/accounts
// Spec: Endpoints
// Behavior: Advisor/admin can filter accounts by customerId

test("PROOF-B-030-BLa — Advisor/admin can filter accounts by customerId", async ({ request }) => {
  // Precondition: User has 'advisor' or 'admin' role
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined();

  // Act
  const { data, status } = await trpcMutation(request, "GET /api/accounts", {
    bankId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in GET /api/accounts
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  // Kills: Remove success path in GET /api/accounts
});
test("PROOF-B-030-BLb — Advisor/admin can filter accounts by customerId requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  const { status } = await trpcMutation(request, "GET /api/accounts", {
    bankId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from GET /api/accounts
});
test("PROOF-B-030-BLc — Advisor/admin can filter accounts by customerId persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined(); // Kills: Don't return id from GET /api/accounts
  const { data: fetched, status } = await trpcQuery(request, "GET /api/accounts",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove GET /api/accounts endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === bankId)).toBe(true); // Kills: Don't persist to DB
});

// PROOF-B-039-BL — Business Logic: POST /api/transactions requires advisor or admin authorization
// Risk: critical | Endpoint: POST /api/transactions
// Spec: Endpoints
// Behavior: POST /api/transactions requires advisor or admin authorization

test("PROOF-B-039-BLa — POST /api/transactions requires advisor or admin authorization", async ({ request }) => {
  // Precondition: valid authenticated user
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined();

  // Act
  const { data, status } = await trpcMutation(request, "POST /api/transactions", {
    bankId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in POST /api/transactions
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  // Kills: Remove success path in POST /api/transactions
});
test("PROOF-B-039-BLb — POST /api/transactions requires advisor or admin authorizati requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  const { status } = await trpcMutation(request, "POST /api/transactions", {
    bankId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from POST /api/transactions
});
test("PROOF-B-039-BLc — POST /api/transactions requires advisor or admin authorizati persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined(); // Kills: Don't return id from POST /api/transactions
  const { data: fetched, status } = await trpcQuery(request, "GET /api/accounts",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove GET /api/accounts endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === bankId)).toBe(true); // Kills: Don't persist to DB
});

// PROOF-B-044-BL — Business Logic: fromAccountId must have sufficient balance for transaction
// Risk: high | Endpoint: POST /api/transactions
// Spec: Endpoints
// Behavior: fromAccountId must have sufficient balance for transaction

test("PROOF-B-044-BLa — balance deducted after fromAccountId must have sufficient balance for tra", async ({ request }) => {
  // Arrange: Create fromAccount and toAccount with known balances
  const fromAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const toAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(fromAccount?.id).toBeDefined();
  expect(toAccount?.id).toBeDefined();

  // Read balance BEFORE transaction
  const { data: fromBefore } = await trpcQuery(request, "GET /api/accounts",
    { bankId: TEST_BANK_ID }, adminCookie);
  const balanceBefore = (Array.isArray(fromBefore) ? fromBefore : [fromBefore])
    .find((a: unknown) => (a as Record<string, unknown>).id === fromAccount.id)
    ?.balance as number ?? 0;
  expect(typeof balanceBefore).toBe("number");
  // Kills: Cannot read balance before transaction

  // Act: Execute the transaction
  const AMOUNT = 1;
  const { status, data } = await trpcMutation(request, "POST /api/transactions", {
    bankId: TEST_BANK_ID,
    fromAccountId: fromAccount.id as number,
    toAccountId: toAccount.id as number,
    amount: AMOUNT,
    description: "Test description",
    idempotencyKey: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200);
  // Kills: Remove success path in POST /api/transactions

  // Read balance AFTER transaction
  const { data: fromAfter } = await trpcQuery(request, "GET /api/accounts",
    { bankId: TEST_BANK_ID }, adminCookie);
  const balanceAfter = (Array.isArray(fromAfter) ? fromAfter : [fromAfter])
    .find((a: unknown) => (a as Record<string, unknown>).id === fromAccount.id)
    ?.balance as number;

  expect(balanceAfter).toBe(balanceBefore - AMOUNT);
  // Kills: Not deducting amount from fromAccount.balance
  expect(balanceAfter).toBeGreaterThanOrEqual(0);
  // Kills: Allow negative balance (insufficient funds check missing)
  // Kills: Remove success path in POST /api/transactions
  // Kills: Not updating balance > after validates in POST /api/transactions
});
test("PROOF-B-044-BLb — fromAccountId must have sufficient balance for transaction requires auth", async ({ request }) => {
  const fromAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const toAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const { status } = await trpcMutation(request, "POST /api/transactions", {
    bankId: TEST_BANK_ID,
    fromAccountId: fromAccount.id as number,
    toAccountId: toAccount.id as number,
    amount: 1,
  }, ""); // No cookie
  expect([401, 403]).toContain(status);
  // Kills: Remove auth middleware from POST /api/transactions
});

// PROOF-B-045-BL — Business Logic: POST /api/transactions returns 422 INSUFFICIENT_BALANCE if fromAccountId has insufficient balance
// Risk: high | Endpoint: POST /api/transactions
// Spec: Endpoints
// Behavior: POST /api/transactions returns 422 INSUFFICIENT_BALANCE if fromAccountId has insufficient balance

test("PROOF-B-045-BLa — POST /api/transactions returns 422 INSUFFICIENT_BALANCE if fromAccount", async ({ request }) => {
  // Precondition: fromAccount.balance < amount
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined();

  // Act
  const { data, status } = await trpcMutation(request, "POST /api/transactions", {
    bankId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in POST /api/transactions
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  // Kills: Remove success path in POST /api/transactions
});
test("PROOF-B-045-BLb — POST /api/transactions returns 422 INSUFFICIENT_BALANCE if f requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  const { status } = await trpcMutation(request, "POST /api/transactions", {
    bankId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from POST /api/transactions
});
test("PROOF-B-045-BLc — POST /api/transactions returns 422 INSUFFICIENT_BALANCE if f persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined(); // Kills: Don't return id from POST /api/transactions
  const { data: fetched, status } = await trpcQuery(request, "GET /api/accounts",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove GET /api/accounts endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === bankId)).toBe(true); // Kills: Don't persist to DB
});

// PROOF-B-046-BL — Business Logic: Amount is deducted from fromAccount and credited to toAccount atomically
// Risk: high | Endpoint: POST /api/transactions
// Spec: Endpoints
// Behavior: Amount is deducted from fromAccount and credited to toAccount atomically

test("PROOF-B-046-BLa — balance deducted after Amount is deducted from fromAccount and credited t", async ({ request }) => {
  // Arrange: Create fromAccount and toAccount with known balances
  const fromAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const toAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(fromAccount?.id).toBeDefined();
  expect(toAccount?.id).toBeDefined();

  // Read balance BEFORE transaction
  const { data: fromBefore } = await trpcQuery(request, "GET /api/accounts",
    { bankId: TEST_BANK_ID }, adminCookie);
  const balanceBefore = (Array.isArray(fromBefore) ? fromBefore : [fromBefore])
    .find((a: unknown) => (a as Record<string, unknown>).id === fromAccount.id)
    ?.balance as number ?? 0;
  expect(typeof balanceBefore).toBe("number");
  // Kills: Cannot read balance before transaction

  // Act: Execute the transaction
  const AMOUNT = 1;
  const { status, data } = await trpcMutation(request, "POST /api/transactions", {
    bankId: TEST_BANK_ID,
    fromAccountId: fromAccount.id as number,
    toAccountId: toAccount.id as number,
    amount: AMOUNT,
    description: "Test description",
    idempotencyKey: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200);
  // Kills: Remove success path in POST /api/transactions

  // Read balance AFTER transaction
  const { data: fromAfter } = await trpcQuery(request, "GET /api/accounts",
    { bankId: TEST_BANK_ID }, adminCookie);
  const balanceAfter = (Array.isArray(fromAfter) ? fromAfter : [fromAfter])
    .find((a: unknown) => (a as Record<string, unknown>).id === fromAccount.id)
    ?.balance as number;

  expect(balanceAfter).toBe(balanceBefore - AMOUNT);
  // Kills: Not deducting amount from fromAccount.balance
  expect(balanceAfter).toBeGreaterThanOrEqual(0);
  // Kills: Allow negative balance (insufficient funds check missing)
  // Kills: Remove success path in POST /api/transactions
  // Kills: Not updating Account balances updated atomically after is deducted from and credited to in POST /api/transactions
});
test("PROOF-B-046-BLb — Amount is deducted from fromAccount and credited to toAccoun requires auth", async ({ request }) => {
  const fromAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const toAccount = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const { status } = await trpcMutation(request, "POST /api/transactions", {
    bankId: TEST_BANK_ID,
    fromAccountId: fromAccount.id as number,
    toAccountId: toAccount.id as number,
    amount: 1,
  }, ""); // No cookie
  expect([401, 403]).toContain(status);
  // Kills: Remove auth middleware from POST /api/transactions
});

// PROOF-B-053-BL — Business Logic: PATCH /api/transactions/:id/status requires admin authorization
// Risk: critical | Endpoint: PATCH /api/transactions/:id/status
// Spec: Endpoints
// Behavior: PATCH /api/transactions/:id/status requires admin authorization

test("PROOF-B-053-BLa — PATCH /api/transactions/:id/status requires admin authorization", async ({ request }) => {
  // Precondition: valid authenticated user
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined();

  // Act
  const { data, status } = await trpcMutation(request, "PATCH /api/transactions/:id/status", {
    bankId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in PATCH /api/transactions/:id/status
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  // Kills: Remove success path in PATCH /api/transactions/:id/status
});
test("PROOF-B-053-BLb — PATCH /api/transactions/:id/status requires admin authorizat requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  const { status } = await trpcMutation(request, "PATCH /api/transactions/:id/status", {
    bankId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from PATCH /api/transactions/:id/status
});
test("PROOF-B-053-BLc — PATCH /api/transactions/:id/status requires admin authorizat persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined(); // Kills: Don't return id from PATCH /api/transactions/:id/status
  const { data: fetched, status } = await trpcQuery(request, "GET /api/accounts",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove GET /api/accounts endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === bankId)).toBe(true); // Kills: Don't persist to DB
});

// PROOF-B-070-BL — Business Logic: DELETE /api/accounts/:id requires admin authorization
// Risk: critical | Endpoint: DELETE /api/accounts/:id
// Spec: Endpoints
// Behavior: DELETE /api/accounts/:id requires admin authorization

test("PROOF-B-070-BLa — DELETE /api/accounts/:id requires admin authorization", async ({ request }) => {
  // Arrange: Create a real resource
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined();

  // Act: Delete resource
  const { status, data } = await trpcMutation(request, "DELETE /api/accounts/:id", {
    bankId,
    bankId: TEST_BANK_ID,
  }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove success path in DELETE /api/accounts/:id

  expect((data as Record<string, unknown>)?.success).toBe(true);
  // Kills: Return success:false on deletion

  // DB-Check: Resource must be gone
  const { status: getStatus } = await trpcQuery(request, "GET /api/accounts",
    { bankId, bankId: TEST_BANK_ID }, adminCookie);
  expect(getStatus).toBe(404);
  // Kills: Soft-delete instead of hard-delete
});

test("PROOF-B-070-BLb — DELETE /api/accounts/:id requires admin authorization requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;

  const { status } = await trpcMutation(request, "DELETE /api/accounts/:id", {
    bankId,
    bankId: TEST_BANK_ID,
  }, ""); // No cookie

  expect([401, 403]).toContain(status);
  // Kills: Remove auth middleware from DELETE /api/accounts/:id
});

// PROOF-B-077-BL — Business Logic: POST /api/accounts/:id/freeze requires admin authorization
// Risk: critical | Endpoint: POST /api/accounts/:id/freeze
// Spec: Endpoints
// Behavior: POST /api/accounts/:id/freeze requires admin authorization

test("PROOF-B-077-BLa — POST /api/accounts/:id/freeze requires admin authorization", async ({ request }) => {
  // Precondition: valid authenticated user
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined();

  // Act
  const { data, status } = await trpcMutation(request, "POST /api/accounts/:id/freeze", {
    bankId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in POST /api/accounts/:id/freeze
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  // Kills: Remove success path in POST /api/accounts/:id/freeze
});
test("PROOF-B-077-BLb — POST /api/accounts/:id/freeze requires admin authorization requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  const { status } = await trpcMutation(request, "POST /api/accounts/:id/freeze", {
    bankId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from POST /api/accounts/:id/freeze
});
test("PROOF-B-077-BLc — POST /api/accounts/:id/freeze requires admin authorization persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined(); // Kills: Don't return id from POST /api/accounts/:id/freeze
  const { data: fetched, status } = await trpcQuery(request, "GET /api/accounts",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove GET /api/accounts endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === bankId)).toBe(true); // Kills: Don't persist to DB
});

// PROOF-B-083-BL — Business Logic: POST /api/accounts/:id/unfreeze requires admin authorization
// Risk: critical | Endpoint: POST /api/accounts/:id/unfreeze
// Spec: Endpoints
// Behavior: POST /api/accounts/:id/unfreeze requires admin authorization

test("PROOF-B-083-BLa — POST /api/accounts/:id/unfreeze requires admin authorization", async ({ request }) => {
  // Precondition: valid authenticated user
  // Arrange: Create a real resource first
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined();

  // Act
  const { data, status } = await trpcMutation(request, "POST /api/accounts/:id/unfreeze", {
    bankId,
    bankId: TEST_BANK_ID,
  }, adminCookie);
  expect(status).toBe(200); // Kills: Remove success path in POST /api/accounts/:id/unfreeze
  expect((data as Record<string, unknown>)?.id).toBeDefined(); // Kills: Return undefined id

  // Kills: Remove success path in POST /api/accounts/:id/unfreeze
});
test("PROOF-B-083-BLb — POST /api/accounts/:id/unfreeze requires admin authorization requires auth", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  const { status } = await trpcMutation(request, "POST /api/accounts/:id/unfreeze", {
    bankId,
    bankId: TEST_BANK_ID,
  }, "");
  expect([401, 403]).toContain(status); // Kills: Remove auth middleware from POST /api/accounts/:id/unfreeze
});
test("PROOF-B-083-BLc — POST /api/accounts/:id/unfreeze requires admin authorization persists to DB", async ({ request }) => {
  const created = await createTestResource(request, adminCookie) as Record<string, unknown>;
  const bankId = created.id as number;
  expect(bankId).toBeDefined(); // Kills: Don't return id from POST /api/accounts/:id/unfreeze
  const { data: fetched, status } = await trpcQuery(request, "GET /api/accounts",
    { bankId: TEST_BANK_ID }, adminCookie);
  expect(status).toBe(200); // Kills: Remove GET /api/accounts endpoint
  const items = Array.isArray(fetched) ? fetched : (fetched as Record<string, unknown[]>)?.items || (fetched as Record<string, unknown[]>)?.tasks || [];
  expect(items.some((r: unknown) => (r as Record<string, unknown>).id === bankId)).toBe(true); // Kills: Don't persist to DB
});