import { expect, test } from "@playwright/test";
import { BASE_URL, trpcMutation, trpcQuery } from "../../helpers/api";
import { getAdminCookie } from "../../helpers/auth";
import { TEST_BANK_ID } from "../../helpers/factories";

let adminCookie: string;

test.beforeAll(async ({ request }) => {
  adminCookie = await getAdminCookie(request);
});

// Proof: PROOF-B-052-IDEMPOTENCY
// Behavior: Failed or reversed transactions have no balance change
// Risk: high
// Kills: Remove duplicate-check before cause no in transactions.status | Not returning existing resource on duplicate cause no | Creating second record instead of returning existing one

function basePayload_PROOF_B_052_IDEMPOTENCY() {
  return {
    id: "1",
    status: "\"processing\"",
  };
}

test.describe("Idempotency: Failed or reversed transactions have no balance change", () => {
  let cookie: string;

  test("duplicate cause no request must not create a second balance change", async ({ request }) => {
    const payload = basePayload_PROOF_B_052_IDEMPOTENCY();
    // First request
    const response1 = await trpcMutation(request, "transactions.status", payload, cookie);
    expect(response1.status).toBeOneOf([200, 201]);
    const id1 = response1.data?.result?.data?.id;
    // Second identical request
    const response2 = await trpcMutation(request, "transactions.status", payload, cookie);
    // Must succeed or return conflict — never 500
    expect(response2.status).toBeOneOf([200, 201, 409]);
    if (response2.status === 200 || response2.status === 201) {
      // If it succeeds, must return the same resource
      const id2 = response2.data?.result?.data?.id;
      if (id1 && id2) {
        expect(id2).toBe(id1);
      }
    }
  });

  test("repeated cause no must not multiply side effects", async ({ request }) => {
    const payload = basePayload_PROOF_B_052_IDEMPOTENCY();
    // Perform the operation twice
    await trpcMutation(request, "transactions.status", payload, cookie);
    await trpcMutation(request, "transactions.status", payload, cookie);
    // Verify the list endpoint does not contain duplicates
    const listResponse = await trpcQuery(request, "transactions.list", { bankId: TEST_BANK_ID }, cookie);
    expect(listResponse.status).toBe(200);
    const items = listResponse.data?.result?.data;
    if (Array.isArray(items)) {
      // Count items matching our payload
      const matchingItems = items.filter((item: Record<string, unknown>) => {
        return Object.entries(payload).every(([k, v]) => item[k] === v);
      });
      // At most one matching item should exist
      expect(matchingItems.length).toBeLessThanOrEqual(1);
    }
  });

  test("cause no with idempotency key must return same result", async ({ request }) => {
    const idempotencyKey = `idem-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const payload = { ...basePayload_PROOF_B_052_IDEMPOTENCY(), idempotencyKey };
    // First call
    const response1 = await trpcMutation(request, "transactions.status", payload, cookie);
    expect(response1.status).toBeOneOf([200, 201, 422]); // 422 if idempotencyKey not supported
    // Second call with same key
    const response2 = await trpcMutation(request, "transactions.status", payload, cookie);
    expect(response2.status).toBeOneOf([200, 201, 409, 422]);
    // If both succeed, they must return identical data
    if ((response1.status === 200 || response1.status === 201) &&
        (response2.status === 200 || response2.status === 201)) {
      const data1 = response1.data?.result?.data;
      const data2 = response2.data?.result?.data;
      if (data1?.id && data2?.id) {
        expect(data2.id).toBe(data1.id);
      }
    }
  });
});

// Proof: PROOF-B-062-IDEMPOTENCY
// Behavior: DELETE /api/accounts/:id returns 409 ALREADY_CLOSED if account is already closed
// Risk: high
// Kills: Remove duplicate-check before returns 409 ALREADY_CLOSED in accounts.delete | Not returning existing resource on duplicate returns 409 ALREADY_CLOSED | Creating second record instead of returning existing one

function basePayload_PROOF_B_062_IDEMPOTENCY() {
  return {
    id: "1",
  };
}

test.describe("Idempotency: DELETE /api/accounts/:id returns 409 ALREADY_CLOSED if account is already closed", () => {
  let cookie: string;

  test("duplicate returns 409 ALREADY_CLOSED request must not create a second if account is already closed", async ({ request }) => {
    const payload = basePayload_PROOF_B_062_IDEMPOTENCY();
    // First request
    const response1 = await trpcMutation(request, "accounts.delete", payload, cookie);
    expect(response1.status).toBeOneOf([200, 201]);
    const id1 = response1.data?.result?.data?.id;
    // Second identical request
    const response2 = await trpcMutation(request, "accounts.delete", payload, cookie);
    // Must succeed or return conflict — never 500
    expect(response2.status).toBeOneOf([200, 201, 409]);
    if (response2.status === 200 || response2.status === 201) {
      // If it succeeds, must return the same resource
      const id2 = response2.data?.result?.data?.id;
      if (id1 && id2) {
        expect(id2).toBe(id1);
      }
    }
  });

  test("repeated returns 409 ALREADY_CLOSED must not multiply side effects", async ({ request }) => {
    const payload = basePayload_PROOF_B_062_IDEMPOTENCY();
    // Perform the operation twice
    await trpcMutation(request, "accounts.delete", payload, cookie);
    await trpcMutation(request, "accounts.delete", payload, cookie);
    // Verify the list endpoint does not contain duplicates
    const listResponse = await trpcQuery(request, "accounts.list", { bankId: TEST_BANK_ID }, cookie);
    expect(listResponse.status).toBe(200);
    const items = listResponse.data?.result?.data;
    if (Array.isArray(items)) {
      // Count items matching our payload
      const matchingItems = items.filter((item: Record<string, unknown>) => {
        return Object.entries(payload).every(([k, v]) => item[k] === v);
      });
      // At most one matching item should exist
      expect(matchingItems.length).toBeLessThanOrEqual(1);
    }
  });

  test("returns 409 ALREADY_CLOSED with idempotency key must return same result", async ({ request }) => {
    const idempotencyKey = `idem-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const payload = { ...basePayload_PROOF_B_062_IDEMPOTENCY(), idempotencyKey };
    // First call
    const response1 = await trpcMutation(request, "accounts.delete", payload, cookie);
    expect(response1.status).toBeOneOf([200, 201, 422]); // 422 if idempotencyKey not supported
    // Second call with same key
    const response2 = await trpcMutation(request, "accounts.delete", payload, cookie);
    expect(response2.status).toBeOneOf([200, 201, 409, 422]);
    // If both succeed, they must return identical data
    if ((response1.status === 200 || response1.status === 201) &&
        (response2.status === 200 || response2.status === 201)) {
      const data1 = response1.data?.result?.data;
      const data2 = response2.data?.result?.data;
      if (data1?.id && data2?.id) {
        expect(data2.id).toBe(data1.id);
      }
    }
  });
});

// Proof: PROOF-B-067-IDEMPOTENCY
// Behavior: POST /api/accounts/:id/freeze returns 409 if already frozen
// Risk: high
// Kills: Remove duplicate-check before returns 409 in accounts.freeze | Not returning existing resource on duplicate returns 409 | Creating second record instead of returning existing one

function basePayload_PROOF_B_067_IDEMPOTENCY() {
  return {
    id: "1",
    reason: "\"test-reason\"",
  };
}

test.describe("Idempotency: POST /api/accounts/:id/freeze returns 409 if already frozen", () => {
  let cookie: string;

  test("duplicate returns 409 request must not create a second if account is already frozen", async ({ request }) => {
    const payload = basePayload_PROOF_B_067_IDEMPOTENCY();
    // First request
    const response1 = await trpcMutation(request, "accounts.freeze", payload, cookie);
    expect(response1.status).toBeOneOf([200, 201]);
    const id1 = response1.data?.result?.data?.id;
    // Second identical request
    const response2 = await trpcMutation(request, "accounts.freeze", payload, cookie);
    // Must succeed or return conflict — never 500
    expect(response2.status).toBeOneOf([200, 201, 409]);
    if (response2.status === 200 || response2.status === 201) {
      // If it succeeds, must return the same resource
      const id2 = response2.data?.result?.data?.id;
      if (id1 && id2) {
        expect(id2).toBe(id1);
      }
    }
  });

  test("repeated returns 409 must not multiply side effects", async ({ request }) => {
    const payload = basePayload_PROOF_B_067_IDEMPOTENCY();
    // Perform the operation twice
    await trpcMutation(request, "accounts.freeze", payload, cookie);
    await trpcMutation(request, "accounts.freeze", payload, cookie);
    // Verify the list endpoint does not contain duplicates
    const listResponse = await trpcQuery(request, "accounts.list", { bankId: TEST_BANK_ID }, cookie);
    expect(listResponse.status).toBe(200);
    const items = listResponse.data?.result?.data;
    if (Array.isArray(items)) {
      // Count items matching our payload
      const matchingItems = items.filter((item: Record<string, unknown>) => {
        return Object.entries(payload).every(([k, v]) => item[k] === v);
      });
      // At most one matching item should exist
      expect(matchingItems.length).toBeLessThanOrEqual(1);
    }
  });

  test("returns 409 with idempotency key must return same result", async ({ request }) => {
    const idempotencyKey = `idem-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const payload = { ...basePayload_PROOF_B_067_IDEMPOTENCY(), idempotencyKey };
    // First call
    const response1 = await trpcMutation(request, "accounts.freeze", payload, cookie);
    expect(response1.status).toBeOneOf([200, 201, 422]); // 422 if idempotencyKey not supported
    // Second call with same key
    const response2 = await trpcMutation(request, "accounts.freeze", payload, cookie);
    expect(response2.status).toBeOneOf([200, 201, 409, 422]);
    // If both succeed, they must return identical data
    if ((response1.status === 200 || response1.status === 201) &&
        (response2.status === 200 || response2.status === 201)) {
      const data1 = response1.data?.result?.data;
      const data2 = response2.data?.result?.data;
      if (data1?.id && data2?.id) {
        expect(data2.id).toBe(data1.id);
      }
    }
  });
});