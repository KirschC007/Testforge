import { expect, test } from "@playwright/test";
import { trpcMutation, trpcQuery } from "../../helpers/api";
import { getCustomerCookie } from "../../helpers/auth";
import { TEST_BANK_ID, createTestResource, getResource } from "../../helpers/factories";

let adminCookie: string;

test.beforeAll(async ({ request }) => {
  adminCookie = await getAdminCookie(request);
});

// PROOF-B-046-STATUS — Status Transition: Transaction creation returns 422 ACCOUNT_NOT_ACTIVE if accounts are not active
// Risk: high
// Spec: Endpoints
// Behavior: Transaction creation returns 422 ACCOUNT_NOT_ACTIVE if accounts are not active

test("PROOF-B-046-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.create",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove returns 422 ACCOUNT_NOT_ACTIVE transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-046-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.create",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.create",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-046-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.create",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-049-STATUS — Status Transition: Allowed transaction status transitions
// Risk: high
// Spec: Endpoints
// Behavior: Allowed transaction status transitions

test("PROOF-B-049-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove allows transitions transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-049-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-049-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-050-STATUS — Status Transition: Forbidden transaction status transitions
// Risk: high
// Spec: Endpoints
// Behavior: Forbidden transaction status transitions

test("PROOF-B-050-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove forbids transitions transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-050-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-050-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-051-STATUS — Status Transition: Reversed transaction restores original balance
// Risk: high
// Spec: Endpoints
// Behavior: Reversed transaction restores original balance

test("PROOF-B-051-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  // Baseline: record counter BEFORE transition
  const { data: before } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  const countBefore = ((before as Record<string, unknown>)?.fromAccount as number) ?? 0;

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove restores transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

  // Side-effect: counter must increment exactly once
  expect((updated as Record<string, unknown>)?.fromAccount).toBe(countBefore + 1);
  // Kills: Remove `fromAccount` credited, `toAccount` debited side-effect

});

test("PROOF-B-051-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-051-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-052-STATUS — Status Transition: Failed or reversed transactions have no balance change
// Risk: high
// Spec: Endpoints
// Behavior: Failed or reversed transactions have no balance change

test("PROOF-B-052-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  // Baseline: record counter BEFORE transition
  const { data: before } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  const countBefore = ((before as Record<string, unknown>)?.Account as number) ?? 0;

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove cause no transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

  // Side-effect: counter must increment exactly once
  expect((updated as Record<string, unknown>)?.Account).toBe(countBefore + 1);
  // Kills: Remove Account balances remain unchanged (if already rolled back or never committed) side-effect

});

test("PROOF-B-052-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-052-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-053-STATUS — Status Transition: PATCH /api/transactions/:id/status returns 422 INVALID_TRANSITION for forbidden transitions
// Risk: high
// Spec: Endpoints
// Behavior: PATCH /api/transactions/:id/status returns 422 INVALID_TRANSITION for forbidden transitions

test("PROOF-B-053-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove returns 422 INVALID_TRANSITION transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-053-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-053-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-059-STATUS — Status Transition: DELETE /api/accounts/:id sets status to closed
// Risk: high
// Spec: Endpoints
// Behavior: DELETE /api/accounts/:id sets status to closed

test("PROOF-B-059-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  // Baseline: record counter BEFORE transition
  const { data: before } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  const countBefore = ((before as Record<string, unknown>)?.Account as number) ?? 0;

  const { status } = await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove sets `status` to transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

  expect((updated as Record<string, unknown>)?.stat).not.toBeNull();
  // Kills: Remove stat = NOW() in handler

  // Side-effect: counter must increment exactly once
  expect((updated as Record<string, unknown>)?.Account).toBe(countBefore + 1);
  // Kills: Remove Account status is `closed` side-effect

});

test("PROOF-B-059-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-059-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-060-STATUS — Status Transition: Account with positive balance cannot be closed
// Risk: high
// Spec: Endpoints
// Behavior: Account with positive balance cannot be closed

test("PROOF-B-060-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove prevents closure of transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

  // Kills: Remove HTTP 422 BALANCE_NOT_ZERO side-effect
});

test("PROOF-B-060-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-060-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-061-STATUS — Status Transition: Account with pending transactions cannot be closed
// Risk: high
// Spec: Endpoints
// Behavior: Account with pending transactions cannot be closed

test("PROOF-B-061-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove prevents closure of transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-061-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-061-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-062-STATUS — Status Transition: DELETE /api/accounts/:id returns 409 ALREADY_CLOSED if account is already closed
// Risk: high
// Spec: Endpoints
// Behavior: DELETE /api/accounts/:id returns 409 ALREADY_CLOSED if account is already closed

test("PROOF-B-062-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove returns 409 ALREADY_CLOSED transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-062-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-062-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "accounts.delete",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-064-STATUS — Status Transition: POST /api/accounts/:id/freeze sets status to frozen
// Risk: high
// Spec: Endpoints
// Behavior: POST /api/accounts/:id/freeze sets status to frozen

test("PROOF-B-064-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  // Baseline: record counter BEFORE transition
  const { data: before } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  const countBefore = ((before as Record<string, unknown>)?.Account as number) ?? 0;

  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove sets `status` to transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

  expect((updated as Record<string, unknown>)?.stat).not.toBeNull();
  // Kills: Remove stat = NOW() in handler

  // Side-effect: counter must increment exactly once
  expect((updated as Record<string, unknown>)?.Account).toBe(countBefore + 1);
  // Kills: Remove Account status is `frozen` side-effect

});

test("PROOF-B-064-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-064-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-065-STATUS — Status Transition: Frozen accounts cannot send transactions
// Risk: high
// Spec: Endpoints
// Behavior: Frozen accounts cannot send transactions

test("PROOF-B-065-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove cannot send transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-065-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-065-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-066-STATUS — Status Transition: Frozen accounts can receive transactions
// Risk: high
// Spec: Endpoints
// Behavior: Frozen accounts can receive transactions

test("PROOF-B-066-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove can receive transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-066-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-066-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-067-STATUS — Status Transition: POST /api/accounts/:id/freeze returns 409 if already frozen
// Risk: high
// Spec: Endpoints
// Behavior: POST /api/accounts/:id/freeze returns 409 if already frozen

test("PROOF-B-067-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove returns 409 transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-067-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-067-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-068-STATUS — Status Transition: POST /api/accounts/:id/freeze returns 422 if account is closed
// Risk: high
// Spec: Endpoints
// Behavior: POST /api/accounts/:id/freeze returns 422 if account is closed

test("PROOF-B-068-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove returns 422 transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-068-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-068-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "accounts.freeze",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-070-STATUS — Status Transition: POST /api/accounts/:id/unfreeze sets status to active
// Risk: high
// Spec: Endpoints
// Behavior: POST /api/accounts/:id/unfreeze sets status to active

test("PROOF-B-070-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  // Baseline: record counter BEFORE transition
  const { data: before } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  const countBefore = ((before as Record<string, unknown>)?.Account as number) ?? 0;

  const { status } = await trpcMutation(request, "accounts.unfreeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove sets `status` to transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

  expect((updated as Record<string, unknown>)?.stat).not.toBeNull();
  // Kills: Remove stat = NOW() in handler

  // Side-effect: counter must increment exactly once
  expect((updated as Record<string, unknown>)?.Account).toBe(countBefore + 1);
  // Kills: Remove Account status is `active` side-effect

});

test("PROOF-B-070-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "accounts.unfreeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "accounts.unfreeze",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-070-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "accounts.unfreeze",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-071-STATUS — Status Transition: POST /api/accounts/:id/unfreeze returns 409 if not frozen
// Risk: high
// Spec: Endpoints
// Behavior: POST /api/accounts/:id/unfreeze returns 409 if not frozen

test("PROOF-B-071-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "accounts.unfreeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove returns 409 transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-071-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "accounts.unfreeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "accounts.unfreeze",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-071-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "accounts.unfreeze",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-072-STATUS — Status Transition: POST /api/accounts/:id/unfreeze returns 422 if account is closed
// Risk: high
// Spec: Endpoints
// Behavior: POST /api/accounts/:id/unfreeze returns 422 if account is closed

test("PROOF-B-072-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "accounts.unfreeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove returns 422 transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-072-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "accounts.unfreeze",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "accounts.unfreeze",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-072-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "accounts.unfreeze",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-073-STATUS — Status Transition: Account status transition active → frozen
// Risk: high
// Spec: Status Machine: accounts
// Behavior: Account status transition active → frozen

test("PROOF-B-073-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove transitions from transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-073-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-073-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-074-STATUS — Status Transition: Account status transition frozen → active
// Risk: high
// Spec: Status Machine: accounts
// Behavior: Account status transition frozen → active

test("PROOF-B-074-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove transitions from transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-074-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-074-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-075-STATUS — Status Transition: Account status transition active → closed (only if balance = 0)
// Risk: high
// Spec: Status Machine: accounts
// Behavior: Account status transition active → closed (only if balance = 0)

test("PROOF-B-075-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove transitions from transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-075-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-075-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-076-STATUS — Status Transition: Account status transition frozen → closed (only if balance = 0)
// Risk: high
// Spec: Status Machine: accounts
// Behavior: Account status transition frozen → closed (only if balance = 0)

test("PROOF-B-076-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove transitions from transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-076-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-076-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-077-STATUS — Status Transition: Account status transition closed → active is forbidden
// Risk: high
// Spec: Status Machine: accounts
// Behavior: Account status transition closed → active is forbidden

test("PROOF-B-077-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove forbids transition transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-077-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-077-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-078-STATUS — Status Transition: Account status transition closed → frozen is forbidden
// Risk: high
// Spec: Status Machine: accounts
// Behavior: Account status transition closed → frozen is forbidden

test("PROOF-B-078-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove forbids transition transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-078-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-078-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-079-STATUS — Status Transition: Transaction status transition pending → processing
// Risk: high
// Spec: Status Machine: transactions
// Behavior: Transaction status transition pending → processing

test("PROOF-B-079-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove transitions from transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-079-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-079-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-080-STATUS — Status Transition: Transaction status transition processing → completed
// Risk: high
// Spec: Status Machine: transactions
// Behavior: Transaction status transition processing → completed

test("PROOF-B-080-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove transitions from transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-080-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-080-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-081-STATUS — Status Transition: Transaction status transition processing → failed
// Risk: high
// Spec: Status Machine: transactions
// Behavior: Transaction status transition processing → failed

test("PROOF-B-081-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove transitions from transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-081-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-081-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-082-STATUS — Status Transition: Transaction status transition completed → reversed
// Risk: high
// Spec: Status Machine: transactions
// Behavior: Transaction status transition completed → reversed

test("PROOF-B-082-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove transitions from transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-082-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-082-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-083-STATUS — Status Transition: Transaction status transition completed → pending is forbidden
// Risk: high
// Spec: Status Machine: transactions
// Behavior: Transaction status transition completed → pending is forbidden

test("PROOF-B-083-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove forbids transition transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-083-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-083-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-084-STATUS — Status Transition: Transaction status transition failed → completed is forbidden
// Risk: high
// Spec: Status Machine: transactions
// Behavior: Transaction status transition failed → completed is forbidden

test("PROOF-B-084-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove forbids transition transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-084-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-084-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-085-STATUS — Status Transition: Transaction status transition reversed → * is forbidden (terminal)
// Risk: high
// Spec: Status Machine: transactions
// Behavior: Transaction status transition reversed → * is forbidden (terminal)

test("PROOF-B-085-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove forbids transitions from transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-085-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-085-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});

// PROOF-B-086-STATUS — Status Transition: Transaction status transition pending → completed is forbidden
// Risk: high
// Spec: Status Machine: transactions
// Behavior: Transaction status transition pending → completed is forbidden

test("PROOF-B-086-STATUSa — pending → completed: transition succeeds with correct side-effects", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;
  expect(resource?.id).toBeDefined();

  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  expect(status).toBe(200);
  // Kills: Remove forbids transition transition from allowed list

  // DB state check
  const { data: updated } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((updated as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Update status field but not persist to DB

});

test("PROOF-B-086-STATUSb — completed → pending: reverse transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Bring to completed state first
  await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "completed", bankId: TEST_BANK_ID }, adminCookie);

  // Attempt reverse transition
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "pending", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow completed→pending reverse transition

  // DB must be unchanged
  const { data: unchanged } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged as Record<string, unknown>)?.status).toBe("completed");
  // Kills: Silent state corruption on rejected transition
});

test("PROOF-B-086-STATUSc — pending → accounts: skip-transition must be rejected", async ({ request }) => {
  const resource = await createTestResource(request, adminCookie) as Record<string, unknown>;

  // Attempt to skip directly to accounts without going through completed
  const { status } = await trpcMutation(request, "transactions.status",
    { id: resource.id, status: "accounts", bankId: TEST_BANK_ID }, adminCookie);

  expect([400, 422]).toContain(status);
  // Kills: Allow skipping intermediate states in the transition chain

  // DB must still be in initial state
  const { data: unchanged2 } = await trpcQuery(request, "accounts.getById",
    { id: resource.id, bankId: TEST_BANK_ID }, adminCookie);
  expect((unchanged2 as Record<string, unknown>)?.status).toBe("pending");
  // Kills: Accept any status value without validating transition chain
});